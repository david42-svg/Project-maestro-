# Phase 3.1 — Chord Prediction Model Training

This is the part that runs on your end, not in the browser. It needs a GPU and real
training data — neither of which are available in the sandbox this project was built in.

## What's here

- **`train_chord_model.ipynb`** — a complete, ready-to-run Colab notebook. Every code cell
  in it has been syntax-checked, and the parsing/windowing logic (everything that doesn't
  require PyTorch or a GPU) has been executed end-to-end against synthetic test data before
  being shipped here. The parts that genuinely need a GPU (training, ONNX export) could not
  be executed ahead of time — that's on you, in Colab.

## How to run it

1. Go to [colab.research.google.com](https://colab.research.google.com), upload
   `train_chord_model.ipynb`.
2. `Runtime` → `Change runtime type` → **T4 GPU**.
3. `Runtime` → `Run all`.
4. **Actually read the output of step 2** (the dataset-loading cell) before it moves on.
   The notebook assumes the Chordonomicon CSV has a column called `chords` containing chords written as root +
   optional sharp(`s`)/flat(`b`) + a concatenated quality suffix — e.g. `C` (C major), `E7` (E dominant 7th),
   `Amin` (A minor), `Fs7` (F#7) — with `<verse_1>`-style structure tags mixed in. This was corrected against a
   real printed sample from the dataset; an earlier version of this notebook assumed Harte's colon syntax
   (`C:maj7`) and was wrong. If what prints doesn't match this format either, stop and report back what you see.
5. Training takes roughly 20–40 minutes on a free T4, depending on how much of the
   500,000-example cap gets used. This is deliberately capped — Chordonomicon has 51 million
   chords across 667,000+ songs, and using all of it isn't necessary for a first working model.
6. At the end, it downloads two files: `chord-model.onnx` and `vocab.json`.

## What to do with the output

Put both files at:

```
project-maestro/models/chord-model.onnx
project-maestro/models/vocab.json
```

Then let Claude know — the browser harness (`js/onnx-lab.js`) currently only knows about the
placeholder diagnostic model. Wiring it up to the real model is a small, separate step once
the file actually exists.

## Known gap, stated plainly

The model expects a verse/chorus/bridge/other "section" input. Nothing in the app currently
*detects* that live — Phase 3's flow-engine classifies vamp/building/sustain/transition, which
is a different taxonomy. Until (or unless) something bridges the two, using the trained model
live means picking the section by hand. The model still works and is still useful with that
manual step; it's just not the fully autonomous loop yet.

## Vocabulary contract

`js/chord-vocab.js` and this notebook's vocabulary were diffed token-for-token to confirm they
build the identical 109-token list in the identical order. If you ever edit one, edit the other
the same way — otherwise index 47 means a different chord in the browser than it does in the
model, silently.
