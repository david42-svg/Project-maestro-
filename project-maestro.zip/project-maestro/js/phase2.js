// phase2.js — UI wiring for "The Musician's Brain"
// Requires: Tonal.js (CDN, loaded in phase2.html) and engine.js (loaded before this file)

(function(){
  'use strict';

  let currentStyle = 'worship';

  const errorBox = document.getElementById('errorBox');
  const chordInput = document.getElementById('chordInput');
  const styleRow = document.getElementById('styleRow');
  const generateBtn = document.getElementById('generateBtn');
  const resultArea = document.getElementById('resultArea');

  const prevBtn = document.getElementById('prevBtn');
  const nextBtn = document.getElementById('nextBtn');
  const stepChordEl = document.getElementById('stepChord');
  const stepSubEl = document.getElementById('stepSub');
  const lhNotesEl = document.getElementById('lhNotes');
  const rhNotesEl = document.getElementById('rhNotes');

  let arrangement = [];
  let stepIndex = 0;

  function showError(msg){ errorBox.textContent = msg; errorBox.classList.add('is-visible'); }
  function clearError(){ errorBox.textContent = ''; errorBox.classList.remove('is-visible'); }

  Array.prototype.slice.call(styleRow.querySelectorAll('.style-btn')).forEach(function(btn){
    btn.classList.toggle('is-active', btn.dataset.style === currentStyle);
    btn.addEventListener('click', function(){
      currentStyle = btn.dataset.style;
      Array.prototype.slice.call(styleRow.querySelectorAll('.style-btn')).forEach(function(b){
        b.classList.toggle('is-active', b === btn);
      });
    });
  });

  function renderStep(){
    const chord = arrangement[stepIndex];
    prevBtn.disabled = stepIndex === 0;
    nextBtn.disabled = stepIndex === arrangement.length - 1;

    if (!chord){
      stepChordEl.textContent = '--';
      stepSubEl.textContent = '';
      lhNotesEl.textContent = '--';
      rhNotesEl.textContent = '--';
      KeyboardView.highlight([], []);
      return;
    }

    stepChordEl.textContent = chord.symbol;

    if (chord.error){
      stepSubEl.innerHTML = '<span class="chord-error">could not parse this chord — skipped</span>';
      lhNotesEl.textContent = '--';
      rhNotesEl.textContent = '--';
      KeyboardView.highlight([], []);
      return;
    }

    stepSubEl.innerHTML = 'Chord ' + (stepIndex + 1) + ' of ' + arrangement.length +
      (chord.moveCost !== null ? ' &middot; <span class="move-cost">' + chord.moveCost + ' semitones moved</span>' : ' &middot; starting voicing');

    lhNotesEl.textContent = chord.lhMidis.map(noteNameFromMidi).join(' ');
    rhNotesEl.textContent = chord.rhMidis.map(noteNameFromMidi).join('  ');

    KeyboardView.highlight(chord.lhMidis, chord.rhMidis);
  }

  prevBtn.addEventListener('click', function(){
    if (stepIndex > 0){ stepIndex -= 1; renderStep(); }
  });
  nextBtn.addEventListener('click', function(){
    if (stepIndex < arrangement.length - 1){ stepIndex += 1; renderStep(); }
  });

  generateBtn.addEventListener('click', function(){
    clearError();

    if (typeof Tonal === 'undefined'){
      showError('The Tonal.js music-theory library failed to load — check your internet connection and reload the page.');
      return;
    }

    const raw = chordInput.value.trim();
    if (!raw){
      showError('Type at least one chord symbol, e.g. Cmaj7 Am7 Fmaj7 G7.');
      return;
    }

    const symbols = raw.split(/[\s,]+/).filter(Boolean);
    arrangement = buildArrangement(symbols, currentStyle);

    const allFailed = arrangement.every(function(c){ return c.error; });
    if (allFailed){
      showError('None of those chord symbols could be parsed. Try standard notation like Cmaj7, Am7, F#m7b5, or G7sus4.');
      resultArea.style.display = 'none';
      return;
    }

    stepIndex = 0;
    resultArea.style.display = '';
    renderStep();
  });

  KeyboardView.build('keyboard');
})();
