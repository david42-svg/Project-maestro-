// flow-engine.js — shared by phase3.js
// Turns a live stream of AudioEngine.snapshot() readings into a "flow state"
// (steady / vamp / building / sustain / transition) using explainable rules,
// not a trained model. See phase3.html footer for what this can and can't do.

const FlowEngine = (function(){
  'use strict';

  const HISTORY_WINDOW_SEC = 12;  // how far back we look for trend detection
  const MIN_HOLD_SEC = 3;         // minimum time in a state before it can change
  const VOTE_STREAK_NEEDED = 3;   // consecutive evaluations a candidate must win before switching

  let history = [];
  let currentState = 'steady';
  let currentStateSince = 0;
  let pendingState = null;
  let pendingStreak = 0;

  function reset(time){
    history = [];
    currentState = 'steady';
    currentStateSince = time || 0;
    pendingState = null;
    pendingStreak = 0;
  }

  function explain(state, sig){
    const reasons = [];
    if (state === 'sustain'){
      reasons.push('energy has stayed low (' + sig.avgDb.toFixed(1) + ' dBFS)');
      if (sig.avgBpmConfidence < 0.3) reasons.push('little rhythmic activity detected');
    } else if (state === 'building'){
      reasons.push('energy is rising (~' + sig.dbSlope.toFixed(2) + ' dB/sec)');
    } else if (state === 'transition'){
      if (sig.keySetSize > 1) reasons.push('the detected key changed recently');
      else reasons.push('energy shifted sharply (~' + sig.dbSlope.toFixed(2) + ' dB/sec)');
    } else if (state === 'vamp'){
      reasons.push('energy and key have both held steady for a while');
    } else {
      reasons.push('no strong pattern yet');
    }
    return reasons;
  }

  function linearSlope(points){
    // points: [{x, y}] — least-squares slope, robust to noisy/alternating values
    // (endpoint differencing is too sensitive to which two samples happen to land
    // at the edges of the window; this averages over everything in it)
    const n = points.length;
    let sumX = 0, sumY = 0, sumXY = 0, sumXX = 0;
    for (let i = 0; i < n; i++){
      sumX += points[i].x; sumY += points[i].y;
      sumXY += points[i].x * points[i].y; sumXX += points[i].x * points[i].x;
    }
    const denom = n * sumXX - sumX * sumX;
    if (denom === 0) return 0;
    return (n * sumXY - sumX * sumY) / denom;
  }

  const BUILD_SLOPE_THRESHOLD = 0.8;      // dB/sec rising -> building
  const TRANSITION_DROP_THRESHOLD = 2.0;  // dB/sec falling -> abrupt drop, likely a section change
  const SUSTAIN_DB_CEILING = -28;         // dBFS below this = quiet
  const SUSTAIN_CONF_CEILING = 0.3;       // and little rhythmic activity
  const VAMP_CONF_FLOOR = 0.3;            // decent rhythmic activity + nothing else triggered = vamp

  function evaluate(time){
    if (history.length < 4){
      return {
        state: currentState, candidate: currentState,
        reasons: ['gathering data'], sinceSeconds: time - currentStateSince,
        signals: null
      };
    }

    const avgDb = history.reduce(function(a, h){ return a + h.db; }, 0) / history.length;
    const dbSlope = linearSlope(history.map(function(h){ return { x: h.time, y: h.db }; }));

    const keySet = new Set();
    history.forEach(function(h){ if (h.keyRoot !== null && h.keyRoot !== undefined) keySet.add(h.keyRoot + '-' + h.keyMode); });

    const avgBpmConfidence = history.reduce(function(a, h){ return a + h.bpmConfidence; }, 0) / history.length;

    // Decision tree, evaluated in priority order (not an additive score) so
    // strong signals can't get diluted by unrelated ones voting the other way.
    let bestState;
    if (keySet.size > 1){
      bestState = 'transition';
    } else if (dbSlope > BUILD_SLOPE_THRESHOLD){
      bestState = 'building';
    } else if (dbSlope < -TRANSITION_DROP_THRESHOLD){
      bestState = 'transition';
    } else if (avgDb < SUSTAIN_DB_CEILING && avgBpmConfidence < SUSTAIN_CONF_CEILING){
      bestState = 'sustain';
    } else if (avgBpmConfidence > VAMP_CONF_FLOOR){
      bestState = 'vamp';
    } else {
      bestState = 'steady';
    }


    if (bestState !== currentState){
      if (bestState === pendingState){
        pendingStreak += 1;
      } else {
        pendingState = bestState;
        pendingStreak = 1;
      }
      const heldLongEnough = (time - currentStateSince) >= MIN_HOLD_SEC;
      if (pendingStreak >= VOTE_STREAK_NEEDED && heldLongEnough){
        currentState = bestState;
        currentStateSince = time;
        pendingState = null;
        pendingStreak = 0;
      }
    } else {
      pendingState = null;
      pendingStreak = 0;
    }

    const signals = { avgDb: avgDb, dbSlope: dbSlope, keyStable: keySet.size <= 1, avgBpmConfidence: avgBpmConfidence, keySetSize: keySet.size };

    return {
      state: currentState,
      candidate: bestState,
      reasons: explain(currentState, signals),
      sinceSeconds: time - currentStateSince,
      signals: signals
    };
  }

  // snapshot: the object returned by AudioEngine.snapshot()
  // time: seconds, any monotonic clock (e.g. audioContext.currentTime)
  function push(snapshot, time){
    history.push({
      time: time,
      db: snapshot.smoothedDb,
      keyRoot: snapshot.keyRoot,
      keyMode: snapshot.keyMode,
      bpm: snapshot.bpm,
      bpmConfidence: snapshot.bpmConfidence
    });
    const cutoff = time - HISTORY_WINDOW_SEC;
    while (history.length && history[0].time < cutoff) history.shift();
    return evaluate(time);
  }

  const STATE_LABELS = {
    steady: 'Steady',
    vamp: 'Vamp',
    building: 'Building',
    sustain: 'Sustain / Prayer',
    transition: 'Transition'
  };

  const STATE_SUGGESTIONS = {
    steady: 'No strong signal yet — just playing.',
    vamp: 'Sounds like you\u2019re holding a loop. Consider staying put, maybe add subtle variation each pass.',
    building: 'Energy is climbing. Consider thickening the voicing or moving the right hand up an octave.',
    sustain: 'Quiet and sustained. Consider a sparser, softer voicing — the Solemn style in Phase 2/4 fits this.',
    transition: 'Something just shifted (key or energy). A section change may be starting.'
  };

  return { push: push, reset: reset, STATE_LABELS: STATE_LABELS, STATE_SUGGESTIONS: STATE_SUGGESTIONS };
})();
