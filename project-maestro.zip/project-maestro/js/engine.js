// engine.js — shared by phase2.js and phase4.js
// Pure music-theory logic (note names, voicing selection, voice leading)
// plus the piano-keyboard visualization component.
// Nothing in this file touches audio — that stays in phase4.js.

// ================================================================
// Note / pitch-class helpers
// ================================================================
const PITCH_NAMES = ['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'];
const LETTER_PC = { C:0, D:2, E:4, F:5, G:7, A:9, B:11 };

function noteNameToPitchClass(name){
  if (!name) return null;
  const m = name.match(/^([A-Ga-g])(#+|b+)?/);
  if (!m) return null;
  let pc = LETTER_PC[m[1].toUpperCase()];
  const accidentals = m[2] || '';
  for (let i = 0; i < accidentals.length; i++){
    pc += accidentals[i] === '#' ? 1 : -1;
  }
  return ((pc % 12) + 12) % 12;
}

function midiFromPitchClassOctave(pc, octave){ return (octave + 1) * 12 + pc; }

function noteNameFromMidi(midi){
  const pc = ((midi % 12) + 12) % 12;
  const octave = Math.floor(midi / 12) - 1;
  return PITCH_NAMES[pc] + octave;
}

// ================================================================
// Style presets — voicing shape + playback feel
// (phase2.js only reads voices/bassOctave/rhBaseOctave/addColorTone;
//  phase4.js additionally reads bassSustain/rhSustain for playback)
// ================================================================
const STYLES = {
  // padHighpassHz cuts unwanted low end out of the right-hand voicing so it
  // doesn't fight the bass note for the same frequency range (standard mix
  // advice: only the bass should own the low end).
  // padLowpassHz tames harsh upper harmonics — the more notes stack at once,
  // the more a bright oscillator's overtones pile up and turn harsh.
  // padGainDb trims the pad synth's level; denser chords need more headroom.
  solemn:  { voices: 3, bassOctave: 2, rhBaseOctave: 4, addColorTone: false, bassSustain: 0.90, rhSustain: 0.95,
             padHighpassHz: 90,  padLowpassHz: 6000, padGainDb: 0  },
  worship: { voices: 4, bassOctave: 3, rhBaseOctave: 4, addColorTone: true,  bassSustain: 0.85, rhSustain: 0.90,
             padHighpassHz: 220, padLowpassHz: 2000, padGainDb: -5 },
  praise:  { voices: 4, bassOctave: 2, rhBaseOctave: 4, addColorTone: true,  bassSustain: 0.55, rhSustain: 0.65,
             padHighpassHz: 160, padLowpassHz: 3800, padGainDb: -4 }
};

// ================================================================
// Voicing tone selection for a single chord
// ================================================================
function getVoicingTones(chordPCs, rootPC, voiceCount, addColorTone){
  let tones = chordPCs.filter(function(pc){ return pc !== rootPC; });

  const ninthPC = (rootPC + 2) % 12;
  const isExtended = chordPCs.length > 4;
  if (addColorTone && !isExtended && tones.indexOf(ninthPC) === -1){
    tones = tones.concat([ninthPC]);
  }

  while (tones.length < voiceCount){ tones.push(rootPC); }

  const fifthPC = (rootPC + 7) % 12;
  const removalOrder = [ninthPC, fifthPC];
  let i = 0;
  while (tones.length > voiceCount && i < removalOrder.length){
    const idx = tones.indexOf(removalOrder[i]);
    if (idx !== -1) tones.splice(idx, 1);
    else i += 1;
  }
  while (tones.length > voiceCount){ tones.pop(); }

  return tones.sort(function(a, b){ return a - b; });
}

// ================================================================
// Stacking (first chord — no previous voicing to lead from)
// ================================================================
function stackTones(baseMidi, tones){
  const result = [];
  let prev = baseMidi - 12;
  for (let i = 0; i < tones.length; i++){
    const pc = tones[i];
    let midi = prev + 1;
    while (((midi % 12) + 12) % 12 !== pc) midi += 1;
    result.push(midi);
    prev = midi;
  }
  return result;
}

// ================================================================
// Minimal-movement voice leading between two chords
// ================================================================
function nearestMidiForPitchClass(referenceMidi, pc){
  const refPc = ((referenceMidi % 12) + 12) % 12;
  let diff = ((pc - refPc) % 12 + 12) % 12;
  if (diff > 6) diff -= 12;
  return referenceMidi + diff;
}

function permutations(arr){
  if (arr.length <= 1) return [arr];
  const result = [];
  for (let i = 0; i < arr.length; i++){
    const rest = arr.slice(0, i).concat(arr.slice(i + 1));
    const subPerms = permutations(rest);
    for (let j = 0; j < subPerms.length; j++){
      result.push([arr[i]].concat(subPerms[j]));
    }
  }
  return result;
}

function voiceLead(prevMidis, targetPCs){
  const indices = targetPCs.map(function(_, i){ return i; });
  const perms = permutations(indices);
  let best = null, bestCost = Infinity;
  for (let p = 0; p < perms.length; p++){
    const perm = perms[p];
    let cost = 0;
    const candidate = new Array(prevMidis.length);
    for (let voice = 0; voice < prevMidis.length; voice++){
      const pc = targetPCs[perm[voice]];
      const midi = nearestMidiForPitchClass(prevMidis[voice], pc);
      candidate[voice] = midi;
      cost += Math.abs(midi - prevMidis[voice]);
    }
    if (cost < bestCost){ bestCost = cost; best = candidate; }
  }
  return { voicing: best.sort(function(a, b){ return a - b; }), cost: bestCost };
}

// ================================================================
// Ensemble context — orthogonal to STYLES (which controls "mood").
// This controls "how much space is there for the piano to fill":
//   lhMode 'single' = one bass note (assumes a bassist already has the low
//     end covered — the left hand just anchors the root, which is what
//     this app always did before this).
//   lhMode 'spread' = the left hand plays its own voice-led 2-note chord
//     (root + fifth) since there's no bassist to lean on — this is what
//     "Two-Handed Spread" means in practice: both hands supplying harmony,
//     not one hand on bass duty.
//   rhVoiceCap trims the right hand's voice count so it doesn't crowd a
//   fuller band; null means "use whatever the style already calls for."
// ================================================================
const ENSEMBLE_CONTEXTS = {
  solo: { lhMode: 'spread', rhVoiceCap: null },
  trio: { lhMode: 'single', rhVoiceCap: null },
  full: { lhMode: 'single', rhVoiceCap: 3 }
};

// ================================================================
// Build the full arrangement for a progression
// (requires Tonal.js to already be loaded on the page)
// ensembleContext defaults to 'trio' when omitted, which reproduces the
// exact single-bass-note behavior this app always had — existing callers
// (Phase 2) don't need to change anything.
// ================================================================
function buildArrangement(symbols, style, ensembleContext){
  const cfg = STYLES[style];
  const ensembleCfg = ENSEMBLE_CONTEXTS[ensembleContext] || ENSEMBLE_CONTEXTS.trio;
  const chords = [];
  let prevRh = null;
  let prevBass = null; // used when lhMode === 'single'
  let prevLh = null;   // used when lhMode === 'spread'

  for (let i = 0; i < symbols.length; i++){
    const raw = symbols[i];
    const spelled = raw.charAt(0).toUpperCase() + raw.slice(1);
    let parsed;
    try { parsed = Tonal.Chord.get(spelled); }
    catch (e){ parsed = { empty: true }; }

    if (!parsed || parsed.empty || !parsed.notes || parsed.notes.length === 0){
      chords.push({ symbol: raw, error: true, lhMidis: [], rhMidis: [], moveCost: null });
      continue;
    }

    const chordPCs = parsed.notes.map(noteNameToPitchClass);
    const rootPC = noteNameToPitchClass(parsed.tonic || parsed.notes[0]);

    let lhMidis;
    if (ensembleCfg.lhMode === 'spread'){
      // Simplification, same spirit as the RH's theoretical 9th: this always
      // uses the root's theoretical perfect fifth, not whatever altered 5th
      // the actual chord might have (e.g. a dim/aug quality). Documented,
      // not hidden — good enough for an open, stable-sounding left hand.
      const fifthPC = (rootPC + 7) % 12;
      const lhTones = [rootPC, fifthPC];
      if (prevLh === null){
        const base = midiFromPitchClassOctave(0, cfg.bassOctave);
        lhMidis = stackTones(base, lhTones);
      } else {
        const led = voiceLead(prevLh, lhTones);
        lhMidis = led.voicing;
      }
      prevLh = lhMidis;
    } else {
      let bassMidi;
      if (prevBass === null) bassMidi = midiFromPitchClassOctave(rootPC, cfg.bassOctave);
      else bassMidi = nearestMidiForPitchClass(prevBass, rootPC);
      prevBass = bassMidi;
      lhMidis = [bassMidi];
    }

    const effectiveVoices = ensembleCfg.rhVoiceCap ? Math.min(cfg.voices, ensembleCfg.rhVoiceCap) : cfg.voices;
    const tones = getVoicingTones(chordPCs, rootPC, effectiveVoices, cfg.addColorTone);
    let rhMidis, moveCost;
    if (prevRh === null){
      const base = midiFromPitchClassOctave(0, cfg.rhBaseOctave);
      rhMidis = stackTones(base, tones);
      moveCost = null;
    } else {
      const led = voiceLead(prevRh, tones);
      rhMidis = led.voicing;
      moveCost = led.cost;
    }
    prevRh = rhMidis;

    chords.push({ symbol: raw, error: false, lhMidis: lhMidis, rhMidis: rhMidis, moveCost: moveCost });
  }

  return chords;
}

// ================================================================
// LiveVoicer — voices a live STREAM of chords one at a time, keeping
// voice-leading continuity across successive calls (buildArrangement
// resets its continuity per array; live input has no array, just a
// running sequence of decisions arriving over time). Reuses the exact
// same getVoicingTones/stackTones/voiceLead/nearestMidiForPitchClass
// buildArrangement already uses, so a live chord looks and plays
// identically to one that came from a typed progression.
//
// quality must be one of the 9 in chord-vocab.js's QUALITIES list
// ('maj','min','7','maj7','min7','m7b5','dim','sus2','sus4').
// ================================================================
const QUALITY_INTERVALS = {
  maj:  [0, 4, 7],
  min:  [0, 3, 7],
  '7':  [0, 4, 7, 10],
  maj7: [0, 4, 7, 11],
  min7: [0, 3, 7, 10],
  m7b5: [0, 3, 6, 10],
  dim:  [0, 3, 6],
  sus2: [0, 2, 7],
  sus4: [0, 5, 7]
};

function qualityToPitchClasses(rootPc, quality){
  const intervals = QUALITY_INTERVALS[quality] || QUALITY_INTERVALS.maj;
  return intervals.map(function(iv){ return (rootPc + iv) % 12; });
}

const LiveVoicer = (function(){
  let prevRh = null;
  let prevBass = null;
  let prevLh = null; // used when lhMode === 'spread'

  function reset(){
    prevRh = null;
    prevBass = null;
    prevLh = null;
  }

  // Returns { lhMidis, rhMidis } for this one incoming chord, voice-led
  // from whatever this same LiveVoicer produced last time.
  function voiceNextChord(rootPc, quality, style, ensembleContext){
    const cfg = STYLES[style];
    const ensembleCfg = ENSEMBLE_CONTEXTS[ensembleContext] || ENSEMBLE_CONTEXTS.trio;
    const chordPCs = qualityToPitchClasses(rootPc, quality);

    let lhMidis;
    if (ensembleCfg.lhMode === 'spread'){
      const fifthPC = (rootPc + 7) % 12;
      const lhTones = [rootPc, fifthPC];
      if (prevLh === null){
        lhMidis = stackTones(midiFromPitchClassOctave(0, cfg.bassOctave), lhTones);
      } else {
        lhMidis = voiceLead(prevLh, lhTones).voicing;
      }
      prevLh = lhMidis;
    } else {
      let bassMidi;
      if (prevBass === null) bassMidi = midiFromPitchClassOctave(rootPc, cfg.bassOctave);
      else bassMidi = nearestMidiForPitchClass(prevBass, rootPc);
      prevBass = bassMidi;
      lhMidis = [bassMidi];
    }

    const effectiveVoices = ensembleCfg.rhVoiceCap ? Math.min(cfg.voices, ensembleCfg.rhVoiceCap) : cfg.voices;
    const tones = getVoicingTones(chordPCs, rootPc, effectiveVoices, cfg.addColorTone);
    let rhMidis;
    if (prevRh === null){
      rhMidis = stackTones(midiFromPitchClassOctave(0, cfg.rhBaseOctave), tones);
    } else {
      rhMidis = voiceLead(prevRh, tones).voicing;
    }
    prevRh = rhMidis;

    return { lhMidis: lhMidis, rhMidis: rhMidis };
  }

  return { reset: reset, voiceNextChord: voiceNextChord };
})();

// ================================================================
// Piano keyboard rendering — call KeyboardView.build('keyboard') once,
// then KeyboardView.highlight(lhMidis, rhMidis) whenever notes change.
// ================================================================
const KeyboardView = (function(){
  const KB_START = 36, KB_END = 84, WHITE_W = 30, BLACK_W = 18;
  const WHITE_PCS = [0, 2, 4, 5, 7, 9, 11];
  let keyNodesByMidi = {};
  let containerEl = null;

  // opts: { whiteWidth, blackWidth } — both optional. Omitting them (as
  // Phase 2/4 do) reproduces the exact original sizing. The live "stage"
  // view passes larger values for a bigger display; key HEIGHT is still
  // controlled by CSS (.key.white / .key.black), scoped via a wrapper
  // class on the container if a page wants taller keys too.
  function build(containerId, opts){
    const whiteW = (opts && opts.whiteWidth) || WHITE_W;
    const blackW = (opts && opts.blackWidth) || BLACK_W;

    containerEl = document.getElementById(containerId);
    keyNodesByMidi = {};
    containerEl.innerHTML = '';

    let whiteIndex = 0;
    const whiteIndexByMidi = {};
    for (let midi = KB_START; midi <= KB_END; midi++){
      const pc = ((midi % 12) + 12) % 12;
      if (WHITE_PCS.indexOf(pc) !== -1){ whiteIndexByMidi[midi] = whiteIndex; whiteIndex += 1; }
    }
    containerEl.style.width = (whiteIndex * whiteW) + 'px';

    for (let midi = KB_START; midi <= KB_END; midi++){
      const pc = ((midi % 12) + 12) % 12;
      if (WHITE_PCS.indexOf(pc) === -1) continue;
      const div = document.createElement('div');
      div.className = 'key white';
      div.style.left = (whiteIndexByMidi[midi] * whiteW) + 'px';
      div.style.width = whiteW + 'px';
      containerEl.appendChild(div);
      keyNodesByMidi[midi] = div;
    }
    for (let midi = KB_START; midi <= KB_END; midi++){
      const pc = ((midi % 12) + 12) % 12;
      if (WHITE_PCS.indexOf(pc) !== -1) continue;
      const leftWhiteIndex = whiteIndexByMidi[midi - 1];
      if (leftWhiteIndex === undefined) continue;
      const div = document.createElement('div');
      div.className = 'key black';
      div.style.left = ((leftWhiteIndex + 1) * whiteW - blackW / 2) + 'px';
      div.style.width = blackW + 'px';
      containerEl.appendChild(div);
      keyNodesByMidi[midi] = div;
    }
  }

  function clear(){
    Object.keys(keyNodesByMidi).forEach(function(midi){
      keyNodesByMidi[midi].classList.remove('active-lh', 'active-rh');
    });
  }

  function highlight(lhMidis, rhMidis){
    clear();
    (lhMidis || []).forEach(function(m){ if (keyNodesByMidi[m]) keyNodesByMidi[m].classList.add('active-lh'); });
    (rhMidis || []).forEach(function(m){ if (keyNodesByMidi[m]) keyNodesByMidi[m].classList.add('active-rh'); });
  }

  return { build: build, highlight: highlight, clear: clear };
})();
