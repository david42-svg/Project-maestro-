// phase4.js — UI wiring for "The Performer"
// All audio/scheduling now lives in performance-engine.js, loaded before this file.

(function(){
  'use strict';

  let currentStyle = 'worship';
  let currentEnsemble = 'trio';

  // ================================================================
  // Web MIDI UI (engine hands back plain data, this file owns the <select>)
  // ================================================================
  const midiConnectBtn = document.getElementById('midiConnectBtn');
  const midiSelect = document.getElementById('midiSelect');
  const midiStatus = document.getElementById('midiStatus');

  function populateMidiSelect(outputs){
    midiSelect.innerHTML = '<option value="">Internal audio only</option>';
    outputs.forEach(function(o){
      const opt = document.createElement('option');
      opt.value = o.id;
      opt.textContent = o.name;
      midiSelect.appendChild(opt);
    });
    midiSelect.style.display = '';
  }

  midiConnectBtn.addEventListener('click', async function(){
    midiStatus.style.display = '';
    const result = await PerformanceEngine.connectMidi(populateMidiSelect);
    if (!result.ok){
      midiStatus.textContent = result.reason === 'unsupported'
        ? 'Web MIDI is not supported in this browser. It works in Chrome or Edge on Android/desktop — Safari and iOS never added support, so on an iPad this app plays through its own internal sound only.'
        : 'MIDI access was blocked. Allow MIDI access for this page and try again.';
      return;
    }
    populateMidiSelect(result.outputs);
    midiStatus.textContent = 'Connected. Choose an output device, or keep "Internal audio only".';
  });

  midiSelect.addEventListener('change', function(){
    PerformanceEngine.selectMidiOutput(midiSelect.value);
  });

  // ================================================================
  // UI wiring
  // ================================================================
  const errorBox = document.getElementById('errorBox');
  const chordInput = document.getElementById('chordInput');
  const styleRow = document.getElementById('styleRow');
  const ensembleRow = document.getElementById('ensembleRow');
  const bpmInput = document.getElementById('bpmInput');
  const beatsInput = document.getElementById('beatsInput');
  const humanizeSelect = document.getElementById('humanizeSelect');
  const syncopationSelect = document.getElementById('syncopationSelect');
  const ghostNotesCheckbox = document.getElementById('ghostNotesCheckbox');
  const generateBtn = document.getElementById('generateBtn');
  const resultArea = document.getElementById('resultArea');

  const playBtn = document.getElementById('playBtn');
  const stopBtn = document.getElementById('stopBtn');
  const loopCheckbox = document.getElementById('loopCheckbox');
  const prevBtn = document.getElementById('prevBtn');
  const nextBtn = document.getElementById('nextBtn');
  const stepChordEl = document.getElementById('stepChord');
  const stepSubEl = document.getElementById('stepSub');
  const lhNotesEl = document.getElementById('lhNotes');
  const rhNotesEl = document.getElementById('rhNotes');

  let arrangement = [];
  let stepIndex = 0;

  function showError(msg){ errorBox.textContent = msg; errorBox.classList.add('is-visible'); }
  function clearError(){ errorBox.textContent = ''; errorBox.classList.remove('is-visible'); }

  Array.prototype.slice.call(styleRow.querySelectorAll('.style-btn')).forEach(function(btn){
    btn.classList.toggle('is-active', btn.dataset.style === currentStyle);
    btn.addEventListener('click', function(){
      currentStyle = btn.dataset.style;
      Array.prototype.slice.call(styleRow.querySelectorAll('.style-btn')).forEach(function(b){
        b.classList.toggle('is-active', b === btn);
      });
      PerformanceEngine.applyStyleToAudioChain(currentStyle);
    });
  });

  Array.prototype.slice.call(ensembleRow.querySelectorAll('.style-btn')).forEach(function(btn){
    btn.classList.toggle('is-active', btn.dataset.ensemble === currentEnsemble);
    btn.addEventListener('click', function(){
      currentEnsemble = btn.dataset.ensemble;
      Array.prototype.slice.call(ensembleRow.querySelectorAll('.style-btn')).forEach(function(b){
        b.classList.toggle('is-active', b === btn);
      });
    });
  });

  function renderChordAtIndex(index){
    const chord = arrangement[index];
    const playing = PerformanceEngine.isActive();
    prevBtn.disabled = playing || index === 0;
    nextBtn.disabled = playing || index === arrangement.length - 1;

    if (!chord){
      stepChordEl.textContent = '--'; stepSubEl.textContent = '';
      lhNotesEl.textContent = '--'; rhNotesEl.textContent = '--';
      KeyboardView.highlight([], []);
      return;
    }
    stepChordEl.textContent = chord.symbol;
    if (chord.error){
      stepSubEl.textContent = 'could not parse this chord — skipped';
      lhNotesEl.textContent = '--'; rhNotesEl.textContent = '--';
      KeyboardView.highlight([], []);
      return;
    }
    stepSubEl.textContent = 'Chord ' + (index + 1) + ' of ' + arrangement.length +
      (chord.moveCost !== null ? ' · ' + chord.moveCost + ' semitones moved' : ' · starting voicing');
    lhNotesEl.textContent = chord.lhMidis.map(noteNameFromMidi).join(' ');
    rhNotesEl.textContent = chord.rhMidis.map(noteNameFromMidi).join('  ');
    KeyboardView.highlight(chord.lhMidis, chord.rhMidis);
  }

  prevBtn.addEventListener('click', function(){
    if (stepIndex > 0){ stepIndex -= 1; renderChordAtIndex(stepIndex); }
  });
  nextBtn.addEventListener('click', function(){
    if (stepIndex < arrangement.length - 1){ stepIndex += 1; renderChordAtIndex(stepIndex); }
  });

  generateBtn.addEventListener('click', function(){
    clearError();
    if (typeof Tonal === 'undefined'){
      showError('The Tonal.js music-theory library failed to load — check your connection and reload.');
      return;
    }
    const raw = chordInput.value.trim();
    if (!raw){ showError('Type at least one chord symbol, e.g. Cmaj7 Am7 Fmaj7 G7.'); return; }

    const symbols = raw.split(/[\s,]+/).filter(Boolean);
    arrangement = buildArrangement(symbols, currentStyle, currentEnsemble);

    const allFailed = arrangement.every(function(c){ return c.error; });
    if (allFailed){
      showError('None of those chord symbols could be parsed. Try standard notation like Cmaj7, Am7, F#m7b5, or G7sus4.');
      resultArea.style.display = 'none';
      return;
    }

    stepIndex = 0;
    resultArea.style.display = '';
    renderChordAtIndex(stepIndex);
  });

  function setPlayingUI(playing){
    playBtn.disabled = playing;
    stopBtn.disabled = !playing;
    prevBtn.disabled = playing || stepIndex === 0;
    nextBtn.disabled = playing || stepIndex === arrangement.length - 1;
  }

  playBtn.addEventListener('click', async function(){
    if (!arrangement.length){ showError('Generate an arrangement first.'); return; }
    clearError();
    setPlayingUI(true);

    await PerformanceEngine.play(arrangement, currentStyle, {
      bpm: Number(bpmInput.value),
      beatsPerChord: Number(beatsInput.value),
      humanize: humanizeSelect.value,
      syncopation: syncopationSelect.value,
      ghostNotes: ghostNotesCheckbox.checked,
      loop: loopCheckbox.checked
    }, {
      onChordChange: function(index){ stepIndex = index; renderChordAtIndex(index); },
      onStop: function(){ setPlayingUI(false); }
    });
  });

  stopBtn.addEventListener('click', function(){
    PerformanceEngine.stop();
    setPlayingUI(false);
  });

  KeyboardView.build('keyboard');
})();
