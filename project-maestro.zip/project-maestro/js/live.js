// live.js — "The Stage": mic listening + arrangement playback shown together.
// Requires audio-engine.js, flow-engine.js, engine.js, performance-engine.js
// (all loaded before this file), Tonal.js and Tone.js (CDN).

(function(){
  'use strict';

  let currentStyle = 'worship';
  let currentEnsemble = 'trio';
  let arrangement = [];

  // ================================================================
  // Listening (mic) — mirrors phase1.js/phase3.js, independent of playback
  // ================================================================
  const listenBtn = document.getElementById('listenBtn');
  const listenStatusText = document.getElementById('listenStatusText');
  const micErrorBox = document.getElementById('micErrorBox');

  const flowStateLabel = document.getElementById('flowStateLabel');
  const flowSince = document.getElementById('flowSince');
  const flowReasons = document.getElementById('flowReasons');

  const bpmValueEl = document.getElementById('bpmValue');
  const keyValueEl = document.getElementById('keyValue');
  const noteValueEl = document.getElementById('noteValue');
  const dbValueEl = document.getElementById('dbValue');

  const harmonizeBtn = document.getElementById('harmonizeBtn');
  const harmonizeStatusText = document.getElementById('harmonizeStatusText');
  const harmonizeErrorBox = document.getElementById('harmonizeErrorBox');

  let listenRafId = null;
  let lastFlowPushTime = 0;
  const FLOW_PUSH_INTERVAL_SEC = 0.5;

  let harmonizeActive = false;
  let harmonizeLastToken = null;
  const PITCH_CONFIDENCE_THRESHOLD = 0.5;

  function showHarmonizeError(msg){ harmonizeErrorBox.textContent = msg; harmonizeErrorBox.classList.add('is-visible'); }
  function clearHarmonizeError(){ harmonizeErrorBox.textContent = ''; harmonizeErrorBox.classList.remove('is-visible'); }

  function showMicError(msg){ micErrorBox.textContent = msg; micErrorBox.classList.add('is-visible'); }
  function clearMicError(){ micErrorBox.textContent = ''; micErrorBox.classList.remove('is-visible'); }

  function renderFlow(result){
    const state = result.state;
    flowStateLabel.textContent = FlowEngine.STATE_LABELS[state] || state;
    flowStateLabel.className = 'flow-state-label flow-' + state;
    flowSince.textContent = 'for ' + Math.round(result.sinceSeconds) + 's';
    flowReasons.textContent = result.reasons.join(' · ');
  }

  function listenUpdateLoop(){
    const s = AudioEngine.snapshot();
    const audioContext = AudioEngine.getAudioContext();
    const now = audioContext ? audioContext.currentTime : 0;

    bpmValueEl.textContent = s.bpm ? Math.round(s.bpm) : '--';
    keyValueEl.textContent = s.keyName || '--';
    noteValueEl.textContent = (s.pitch && s.pitch.confidence >= PITCH_CONFIDENCE_THRESHOLD)
      ? AudioEngine.PITCH_NAMES[s.pitch.pitchClass] : '--';
    dbValueEl.textContent = s.smoothedDb <= -59.5 ? '-∞' : s.smoothedDb.toFixed(1);

    if (now - lastFlowPushTime >= FLOW_PUSH_INTERVAL_SEC){
      lastFlowPushTime = now;
      renderFlow(FlowEngine.push(s, now));
    }

    if (harmonizeActive){
      runHarmonizeStep(s, now);
    }

    listenRafId = requestAnimationFrame(listenUpdateLoop);
  }

  async function startListening(){
    clearMicError();
    listenBtn.disabled = true;
    listenStatusText.textContent = 'Requesting mic…';

    const result = await AudioEngine.start();

    if (!result.ok){
      listenBtn.disabled = false;
      listenStatusText.textContent = 'Not listening';
      if (result.reason === 'insecure-context'){
        showMicError('This page needs HTTPS (or localhost) for microphone access.');
      } else if (result.reason === 'unsupported'){
        showMicError('This browser does not support microphone capture.');
      } else if (result.reason === 'mic-error'){
        const err = result.error;
        showMicError(err && err.name === 'NotAllowedError'
          ? 'Microphone access was blocked. Allow it in your browser settings and try again.'
          : 'Could not start the microphone.');
      }
      return;
    }

    listenBtn.disabled = false;
    listenBtn.classList.add('is-listening');
    listenBtn.textContent = '⏸ Stop listening';
    listenStatusText.textContent = 'Listening';

    lastFlowPushTime = 0;
    FlowEngine.reset(0);
    listenRafId = requestAnimationFrame(listenUpdateLoop);
  }

  function stopListening(){
    if (listenRafId) cancelAnimationFrame(listenRafId);
    listenRafId = null;
    AudioEngine.stop();

    listenBtn.classList.remove('is-listening');
    listenBtn.textContent = '▶ Start listening';
    listenStatusText.textContent = 'Not listening';

    bpmValueEl.textContent = '--';
    keyValueEl.textContent = '--';
    noteValueEl.textContent = '--';
    dbValueEl.textContent = '-∞';
    flowStateLabel.textContent = 'Steady';
    flowStateLabel.className = 'flow-state-label flow-steady';
    flowSince.textContent = 'for 0s';
    flowReasons.textContent = 'not listening';

    // Auto-harmonize depends entirely on the mic — stop it too rather than
    // leaving it "on" with no input feeding it.
    if (harmonizeActive) stopHarmonizing();
  }

  listenBtn.addEventListener('click', function(){
    if (AudioEngine.isRunning()) stopListening();
    else startListening();
  });

  // ================================================================
  // Auto-harmonize (Solo, rule-based) — reads the same snapshot the
  // listening loop already computed each frame; no separate polling.
  // ================================================================
  function runHarmonizeStep(s, now){
    if (s.keyRoot === null || s.keyRoot === undefined){
      harmonizeStatusText.textContent = 'Waiting for a key to be established…';
      return;
    }
    if (!s.pitch || s.pitch.confidence < PITCH_CONFIDENCE_THRESHOLD){
      return; // no confident pitch this cycle — hold whatever's already sounding
    }

    const chord = Harmonizer.harmonize(s.pitch.pitchClass, s.keyRoot, s.keyMode, now);
    if (!chord) return;

    if (chord.token !== harmonizeLastToken){
      harmonizeLastToken = chord.token;
      const voicing = LiveVoicer.voiceNextChord(chord.rootPc, chord.quality, currentStyle, currentEnsemble);
      PerformanceEngine.triggerLiveChord(voicing.lhMidis, voicing.rhMidis);
      stageChordEl.textContent = chord.token;
      stageChordSubEl.textContent = 'auto-harmonized · ' + chord.degree;
      KeyboardView.highlight(voicing.lhMidis, voicing.rhMidis);
    }
    harmonizeStatusText.textContent = 'Following: ' + chord.token + ' (' + chord.degree + ')';
  }

  async function startHarmonizing(){
    clearHarmonizeError();
    if (!AudioEngine.isRunning()){
      showHarmonizeError('Start Listening above first — auto-harmonize needs the mic running.');
      return;
    }
    if (currentEnsemble !== 'solo'){
      showHarmonizeError('Auto-harmonize needs Solo ensemble context (below) — it gives the left hand its own chord since there\u2019s no bass player to lean on.');
      return;
    }

    harmonizeBtn.disabled = true;
    await PerformanceEngine.startLive(currentStyle);
    Harmonizer.reset();
    LiveVoicer.reset();
    harmonizeLastToken = null;

    harmonizeActive = true;
    harmonizeBtn.disabled = false;
    harmonizeBtn.classList.add('is-listening');
    harmonizeBtn.textContent = '⏸ Stop auto-harmonize';
    harmonizeStatusText.textContent = 'Listening for a note…';
  }

  function stopHarmonizing(){
    harmonizeActive = false;
    PerformanceEngine.stopLive();
    harmonizeBtn.classList.remove('is-listening');
    harmonizeBtn.textContent = '▶ Start auto-harmonize';
    harmonizeStatusText.textContent = 'Off';
  }

  harmonizeBtn.addEventListener('click', function(){
    if (harmonizeActive) stopHarmonizing();
    else startHarmonizing();
  });
  // Performance (playback) — mirrors phase4.js, independent of listening
  // ================================================================
  const errorBox = document.getElementById('errorBox');
  const chordInput = document.getElementById('chordInput');
  const styleRow = document.getElementById('styleRow');
  const ensembleRow = document.getElementById('ensembleRow');
  const bpmInput = document.getElementById('bpmInput');
  const beatsInput = document.getElementById('beatsInput');
  const humanizeSelect = document.getElementById('humanizeSelect');
  const syncopationSelect = document.getElementById('syncopationSelect');
  const ghostNotesCheckbox = document.getElementById('ghostNotesCheckbox');
  const loopCheckbox = document.getElementById('loopCheckbox');
  const playBtn = document.getElementById('playBtn');
  const stopBtn = document.getElementById('stopBtn');

  const stageChordEl = document.getElementById('stageChord');
  const stageChordSubEl = document.getElementById('stageChordSub');

  function showError(msg){ errorBox.textContent = msg; errorBox.classList.add('is-visible'); }
  function clearError(){ errorBox.textContent = ''; errorBox.classList.remove('is-visible'); }

  Array.prototype.slice.call(styleRow.querySelectorAll('.style-btn')).forEach(function(btn){
    btn.classList.toggle('is-active', btn.dataset.style === currentStyle);
    btn.addEventListener('click', function(){
      currentStyle = btn.dataset.style;
      Array.prototype.slice.call(styleRow.querySelectorAll('.style-btn')).forEach(function(b){
        b.classList.toggle('is-active', b === btn);
      });
      PerformanceEngine.applyStyleToAudioChain(currentStyle);
    });
  });

  Array.prototype.slice.call(ensembleRow.querySelectorAll('.style-btn')).forEach(function(btn){
    btn.classList.toggle('is-active', btn.dataset.ensemble === currentEnsemble);
    btn.addEventListener('click', function(){
      currentEnsemble = btn.dataset.ensemble;
      Array.prototype.slice.call(ensembleRow.querySelectorAll('.style-btn')).forEach(function(b){
        b.classList.toggle('is-active', b === btn);
      });
    });
  });

  function renderStageChord(index, chord){
    if (!chord){
      stageChordEl.textContent = '--';
      stageChordSubEl.textContent = '';
      KeyboardView.highlight([], []);
      return;
    }
    stageChordEl.textContent = chord.symbol;
    if (chord.error){
      stageChordSubEl.textContent = 'could not parse — skipped';
      KeyboardView.highlight([], []);
      return;
    }
    stageChordSubEl.textContent = 'chord ' + (index + 1) + ' of ' + arrangement.length;
    KeyboardView.highlight(chord.lhMidis, chord.rhMidis);
  }

  function setPlayingUI(playing){
    playBtn.disabled = playing;
    stopBtn.disabled = !playing;
  }

  playBtn.addEventListener('click', async function(){
    clearError();
    if (typeof Tonal === 'undefined'){
      showError('The Tonal.js music-theory library failed to load — check your connection and reload.');
      return;
    }
    const raw = chordInput.value.trim();
    if (!raw){ showError('Type at least one chord symbol, e.g. Cmaj7 Am7 Fmaj7 G7.'); return; }

    const symbols = raw.split(/[\s,]+/).filter(Boolean);
    arrangement = buildArrangement(symbols, currentStyle, currentEnsemble);

    const allFailed = arrangement.every(function(c){ return c.error; });
    if (allFailed){
      showError('None of those chord symbols could be parsed. Try standard notation like Cmaj7, Am7, F#m7b5, or G7sus4.');
      return;
    }

    setPlayingUI(true);
    await PerformanceEngine.play(arrangement, currentStyle, {
      bpm: Number(bpmInput.value),
      beatsPerChord: Number(beatsInput.value),
      humanize: humanizeSelect.value,
      syncopation: syncopationSelect.value,
      ghostNotes: ghostNotesCheckbox.checked,
      loop: loopCheckbox.checked
    }, {
      onChordChange: renderStageChord,
      onStop: function(){ setPlayingUI(false); }
    });
  });

  stopBtn.addEventListener('click', function(){
    PerformanceEngine.stop();
    setPlayingUI(false);
  });

  KeyboardView.build('keyboard', { whiteWidth: 42, blackWidth: 26 });
})();
