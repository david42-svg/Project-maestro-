// pitch-detector.js — YIN algorithm for real-time monophonic pitch detection.
// Pure math, no DOM/audio-API dependency in the core function (yinDetect),
// which is what makes it possible to test against synthetic tones before it
// ever touches a real microphone. The thin wrapper at the bottom is the only
// part that actually reads from an AnalyserNode.
//
// Reference: de Cheveigné & Kawahara, "YIN, a fundamental frequency estimator
// for speech and music" (2002) — the standard real-time monophonic pitch
// detector, used in tuner apps and vocal pitch tools generally.

const PitchDetector = (function(){
  'use strict';

  const DEFAULT_THRESHOLD = 0.15;
  const DEFAULT_MIN_FREQ = 70;    // low end of the vocal range (low male voice)
  const DEFAULT_MAX_FREQ = 1000;  // high end (covers soprano + headroom)

  // Core YIN estimator. buffer: Float32Array of time-domain samples.
  // Returns { freq, confidence } or null if no reliable pitch was found
  // (silence, noise, or genuinely unvoiced audio).
  function yinDetect(buffer, sampleRate, opts){
    opts = opts || {};
    const threshold = opts.threshold || DEFAULT_THRESHOLD;
    const minFreq = opts.minFreq || DEFAULT_MIN_FREQ;
    const maxFreq = opts.maxFreq || DEFAULT_MAX_FREQ;

    const tauMin = Math.max(1, Math.floor(sampleRate / maxFreq));
    const tauMax = Math.min(Math.floor(sampleRate / minFreq), Math.floor(buffer.length / 2) - 1);
    if (tauMax <= tauMin) return null;

    const W = buffer.length;
    const d = new Float32Array(tauMax + 1);

    // Steps 1+2: difference function, then cumulative-mean normalization,
    // combined in one pass (standard YIN optimization).
    let runningSum = 0;
    for (let tau = 1; tau <= tauMax; tau++){
      let sum = 0;
      for (let j = 0; j < W - tau; j++){
        const diff = buffer[j] - buffer[j + tau];
        sum += diff * diff;
      }
      runningSum += sum;
      d[tau] = runningSum === 0 ? 1 : (sum * tau) / runningSum;
    }

    // Step 3: first dip below threshold, then descend to its local minimum.
    let bestTau = -1;
    for (let tau = tauMin; tau <= tauMax; tau++){
      if (d[tau] < threshold){
        while (tau + 1 <= tauMax && d[tau + 1] < d[tau]) tau++;
        bestTau = tau;
        break;
      }
    }
    if (bestTau === -1){
      // Nothing crossed the threshold — likely silence or non-tonal noise.
      // Don't guess; report no pitch rather than a low-confidence one.
      return null;
    }

    // Step 4: parabolic interpolation around bestTau for sub-sample precision.
    let betterTau = bestTau;
    if (bestTau > tauMin && bestTau < tauMax){
      const s0 = d[bestTau - 1], s1 = d[bestTau], s2 = d[bestTau + 1];
      const denom = 2 * s1 - s2 - s0;
      if (denom !== 0){
        betterTau = bestTau + (s2 - s0) / (2 * denom);
      }
    }

    const freq = sampleRate / betterTau;
    const confidence = Math.max(0, Math.min(1, 1 - d[bestTau]));
    return { freq: freq, confidence: confidence };
  }

  // freq -> nearest pitch class (0-11) and cents-off-center, reusing the
  // same MIDI conversion formula already used elsewhere in this project
  // (audio-engine.js's chroma extraction).
  function freqToPitchClass(freq){
    if (!freq || freq <= 0) return null;
    const midi = 69 + 12 * Math.log2(freq / 440);
    const rounded = Math.round(midi);
    const cents = (midi - rounded) * 100;
    const pc = ((rounded % 12) + 12) % 12;
    return { pitchClass: pc, midi: rounded, centsOff: cents };
  }

  // ---------------------------------------------------------------
  // Live wrapper — the only part that touches an AnalyserNode.
  // Call detectFromAnalyser(analyserNode, sampleRate) periodically (a few
  // times a second is plenty — vocal notes don't change faster than that).
  // ---------------------------------------------------------------
  function detectFromAnalyser(analyserNode, sampleRate, opts){
    const buffer = new Float32Array(analyserNode.fftSize);
    analyserNode.getFloatTimeDomainData(buffer);
    const result = yinDetect(buffer, sampleRate, opts);
    if (!result) return null;
    const pc = freqToPitchClass(result.freq);
    if (!pc) return null;
    return { freq: result.freq, confidence: result.confidence, pitchClass: pc.pitchClass, midi: pc.midi, centsOff: pc.centsOff };
  }

  return {
    yinDetect: yinDetect,
    freqToPitchClass: freqToPitchClass,
    detectFromAnalyser: detectFromAnalyser
  };
})();
