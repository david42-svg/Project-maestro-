// phase1.js — UI wiring for "The Ear"
// All DSP (tempo/key/dynamics) now lives in audio-engine.js, loaded before this file.

(function(){
  'use strict';

  const PITCH_NAMES = AudioEngine.PITCH_NAMES;

  // ---------------------------------------------------------------
  // DOM references
  // ---------------------------------------------------------------
  const startGate = document.getElementById('startGate');
  const startBtn = document.getElementById('startBtn');
  const stopBtn = document.getElementById('stopBtn');
  const liveArea = document.getElementById('liveArea');
  const errorBox = document.getElementById('errorBox');
  const statusIndicator = document.getElementById('statusIndicator');
  const statusText = document.getElementById('statusText');
  const sampleRateLabel = document.getElementById('sampleRateLabel');

  const scopeCanvas = document.getElementById('scope');
  const scopeCtx = scopeCanvas.getContext('2d');

  const bpmValueEl = document.getElementById('bpmValue');
  const bpmConfidenceFill = document.getElementById('bpmConfidenceFill');
  const bpmConfidenceText = document.getElementById('bpmConfidenceText');
  const beatDot = document.getElementById('beatDot');

  const keyValueEl = document.getElementById('keyValue');
  const keyConfidenceFill = document.getElementById('keyConfidenceFill');
  const keyConfidenceText = document.getElementById('keyConfidenceText');
  const chromaBarsEl = document.getElementById('chromaBars');
  const chromaLabelsEl = document.getElementById('chromaLabels');

  const dbValueEl = document.getElementById('dbValue');
  const vuFill = document.getElementById('vuFill');
  const vuPeak = document.getElementById('vuPeak');

  const chromaBarNodes = [];
  PITCH_NAMES.forEach(function(name){
    const bar = document.createElement('div');
    bar.className = 'chroma-bar';
    chromaBarsEl.appendChild(bar);
    chromaBarNodes.push(bar);

    const label = document.createElement('span');
    label.textContent = name;
    chromaLabelsEl.appendChild(label);
  });

  let rafId = null;
  let nextFlashTime = undefined;

  // ---------------------------------------------------------------
  // Waveform scope rendering
  // ---------------------------------------------------------------
  function resizeCanvas(){
    const dpr = window.devicePixelRatio || 1;
    const rect = scopeCanvas.getBoundingClientRect();
    scopeCanvas.width = rect.width * dpr;
    scopeCanvas.height = rect.height * dpr;
    scopeCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  function drawScope(){
    const analyserNode = AudioEngine.getAnalyserNode();
    if (!analyserNode) return;
    const bufferLength = analyserNode.fftSize;
    const dataArray = new Float32Array(bufferLength);
    analyserNode.getFloatTimeDomainData(dataArray);

    const rect = scopeCanvas.getBoundingClientRect();
    const w = rect.width, h = rect.height;

    scopeCtx.clearRect(0, 0, w, h);

    scopeCtx.strokeStyle = 'rgba(255,255,255,0.06)';
    scopeCtx.lineWidth = 1;
    scopeCtx.beginPath();
    scopeCtx.moveTo(0, h / 2);
    scopeCtx.lineTo(w, h / 2);
    scopeCtx.stroke();

    scopeCtx.lineWidth = 1.5;
    scopeCtx.strokeStyle = '#3ddbc0';
    scopeCtx.beginPath();
    const step = Math.max(1, Math.floor(bufferLength / w));
    let x = 0;
    for (let i = 0; i < bufferLength; i += step){
      const v = dataArray[i];
      const y = (0.5 - v * 0.45) * h;
      if (x === 0) scopeCtx.moveTo(x, y);
      else scopeCtx.lineTo(x, y);
      x += 1;
    }
    scopeCtx.stroke();
  }

  // ---------------------------------------------------------------
  // UI update loop
  // ---------------------------------------------------------------
  function updateUI(){
    const s = AudioEngine.snapshot();
    const audioContext = AudioEngine.getAudioContext();

    if (s.bpm){
      bpmValueEl.textContent = Math.round(s.bpm);
      bpmConfidenceFill.style.width = Math.round(s.bpmConfidence * 100) + '%';
      bpmConfidenceText.textContent = Math.round(s.bpmConfidence * 100) + '%';

      if (s.beatInterval && s.lastBeatTime !== null && audioContext){
        const now = audioContext.currentTime;
        let next = s.lastBeatTime;
        while (next < now) next += s.beatInterval;
        if (next - now < 0.05 || nextFlashTime === undefined){
          nextFlashTime = next;
        }
        if (nextFlashTime !== undefined && now >= nextFlashTime){
          beatDot.classList.add('flash');
          setTimeout(function(){ beatDot.classList.remove('flash'); }, 90);
          nextFlashTime += s.beatInterval;
        }
      }
    } else {
      bpmValueEl.textContent = '--';
      bpmConfidenceFill.style.width = '0%';
      bpmConfidenceText.textContent = '0%';
    }

    if (s.keyName){
      keyValueEl.textContent = s.keyName;
      keyConfidenceFill.style.width = Math.round(s.keyConfidence * 100) + '%';
      keyConfidenceText.textContent = Math.round(s.keyConfidence * 100) + '%';
    } else {
      keyValueEl.textContent = '--';
      keyConfidenceFill.style.width = '0%';
      keyConfidenceText.textContent = '0%';
    }

    const maxChroma = Math.max.apply(null, s.chroma) || 1;
    chromaBarNodes.forEach(function(bar, i){
      const pct = Math.max(8, (s.chroma[i] / maxChroma) * 100);
      bar.style.height = pct + '%';
      bar.classList.toggle('is-root', !!s.keyName && i === s.keyRoot);
    });

    if (s.smoothedDb <= -59.5){
      dbValueEl.textContent = '-∞';
    } else {
      dbValueEl.textContent = s.smoothedDb.toFixed(1);
    }
    const fillPct = Math.max(0, Math.min(100, (s.smoothedDb + 60) / 60 * 100));
    const peakPct = Math.max(0, Math.min(100, (s.peakDb + 60) / 60 * 100));
    vuFill.style.width = fillPct + '%';
    vuPeak.style.left = peakPct + '%';

    drawScope();
    rafId = requestAnimationFrame(updateUI);
  }

  // ---------------------------------------------------------------
  // Error handling / status helpers
  // ---------------------------------------------------------------
  function showError(message){
    errorBox.textContent = message;
    errorBox.classList.add('is-visible');
  }
  function clearError(){
    errorBox.textContent = '';
    errorBox.classList.remove('is-visible');
  }
  function setStatus(live, label){
    statusText.textContent = label;
    statusIndicator.classList.toggle('is-live', !!live);
  }

  // ---------------------------------------------------------------
  // Start / stop
  // ---------------------------------------------------------------
  async function start(){
    clearError();
    startBtn.disabled = true;
    setStatus(false, 'Requesting mic…');

    const result = await AudioEngine.start();

    if (!result.ok){
      startBtn.disabled = false;
      setStatus(false, 'Idle');
      if (result.reason === 'insecure-context'){
        showError('This page needs to be served over HTTPS (or opened at localhost) for microphone access to work. Upload it to a secure host and reopen it there.');
      } else if (result.reason === 'unsupported'){
        showError('This browser does not support microphone capture (getUserMedia). Try a recent version of Chrome, Edge, or Firefox.');
      } else if (result.reason === 'mic-error'){
        const err = result.error;
        if (err && err.name === 'NotAllowedError'){
          showError('Microphone access was blocked. Allow microphone access for this page in your browser settings, then press Start again.');
        } else if (err && err.name === 'NotFoundError'){
          showError('No microphone was found on this device. Connect a mic or check your input settings, then try again.');
        } else {
          showError('Could not start the microphone (' + (err && err.message ? err.message : 'unknown error') + ').');
        }
      }
      return;
    }

    sampleRateLabel.textContent = Math.round(result.sampleRate / 100) / 10 + ' kHz';

    startGate.style.display = 'none';
    liveArea.style.display = '';
    stopBtn.style.display = '';
    setStatus(true, 'Listening');
    resizeCanvas();

    nextFlashTime = undefined;
    rafId = requestAnimationFrame(updateUI);
  }

  function stop(){
    if (rafId) cancelAnimationFrame(rafId);
    rafId = null;
    AudioEngine.stop();

    liveArea.style.display = 'none';
    startGate.style.display = '';
    stopBtn.style.display = 'none';
    startBtn.disabled = false;
    setStatus(false, 'Idle');
  }

  startBtn.addEventListener('click', start);
  stopBtn.addEventListener('click', stop);
  window.addEventListener('resize', function(){
    if (liveArea.style.display !== 'none') resizeCanvas();
  });

})();
