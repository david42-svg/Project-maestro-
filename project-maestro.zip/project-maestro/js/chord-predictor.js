// chord-predictor.js — Phase 3.1: real trained-model inference.
// Requires chord-vocab.js and onnxruntime-web (ort) loaded before this file.
//
// This is the trained model (chord-model.onnx), not the diagnostic
// placeholder in onnx-lab.js. Same execution-provider fallback pattern
// (WebGPU, then WASM) since that risk doesn't change just because the
// model content did.

const ChordPredictor = (function(){
  'use strict';

  const MODEL_URL = 'models/chord-model.onnx';
  const HISTORY_LEN = 8;

  let session = null;
  let sessionEP = null;

  async function loadSession(onLog){
    onLog = onLog || function(){};
    if (typeof ort === 'undefined'){
      throw new Error('onnxruntime-web failed to load — check your internet connection.');
    }
    const attempts = [
      { label: 'webgpu', providers: ['webgpu'] },
      { label: 'wasm', providers: ['wasm'] }
    ];
    for (let i = 0; i < attempts.length; i++){
      const attempt = attempts[i];
      try{
        onLog('Trying execution provider: ' + attempt.label + '…');
        const t0 = performance.now();
        session = await ort.InferenceSession.create(MODEL_URL, {
          executionProviders: attempt.providers,
          graphOptimizationLevel: 'all'
        });
        sessionEP = attempt.label;
        onLog('Session created with "' + attempt.label + '" in ' + (performance.now() - t0).toFixed(0) + 'ms.');
        return;
      } catch (err){
        onLog('"' + attempt.label + '" failed: ' + (err && err.message ? err.message : err));
      }
    }
    throw new Error('No execution provider worked (tried webgpu, wasm).');
  }

  // Converts an array of chord tokens (already in js/chord-vocab.js format,
  // e.g. "Cmaj", "Amin7") into a fixed 8-length history: right-padded on the
  // LEFT with <pad> if shorter, truncated to the most recent 8 if longer.
  function tokensToHistoryIds(chordTokens){
    const ids = chordTokens.map(function(t){ return ChordVocab.indexOf(t); });
    if (ids.length >= HISTORY_LEN){
      return ids.slice(ids.length - HISTORY_LEN);
    }
    const padCount = HISTORY_LEN - ids.length;
    return new Array(padCount).fill(0).concat(ids); // 0 = <pad>
  }

  function softmax(logits){
    const max = Math.max.apply(null, logits);
    const exps = logits.map(function(v){ return Math.exp(v - max); });
    const sum = exps.reduce(function(a, b){ return a + b; }, 0);
    return exps.map(function(v){ return v / sum; });
  }

  const SECTION_NAMES = ['verse', 'chorus', 'bridge', 'other'];

  // chordTokens: array of strings in chord-vocab.js format (e.g. ['Cmaj','Amin',...])
  // section: one of 'verse' | 'chorus' | 'bridge' | 'other'
  // topN: how many ranked predictions to return (default 5)
  async function predict(chordTokens, section, topN, onLog){
    onLog = onLog || function(){};
    if (!session){
      await loadSession(onLog);
    }

    const historyIds = tokensToHistoryIds(chordTokens);
    const historyTensor = new ort.Tensor('int64', BigInt64Array.from(historyIds.map(BigInt)), [1, HISTORY_LEN]);

    const sectionData = new Float32Array(4);
    const sectionIdx = SECTION_NAMES.indexOf(section);
    sectionData[sectionIdx === -1 ? 3 : sectionIdx] = 1.0;
    const sectionTensor = new ort.Tensor('float32', sectionData, [1, 4]);

    const t0 = performance.now();
    const results = await session.run({ chord_history: historyTensor, section: sectionTensor });
    const runMs = performance.now() - t0;

    const logits = Array.from(results.next_chord_logits.data);
    const probs = softmax(logits);

    const ranked = probs
      .map(function(p, i){ return { token: ChordVocab.tokenAt(i), prob: p }; })
      .filter(function(r){ return r.token !== '<pad>'; })
      .sort(function(a, b){ return b.prob - a.prob; })
      .slice(0, topN || 5);

    return { ranked: ranked, ep: sessionEP, runMs: runMs, historyUsed: historyIds.map(ChordVocab.tokenAt) };
  }

  function isReady(){ return session !== null; }

  return { predict: predict, isReady: isReady, HISTORY_LEN: HISTORY_LEN };
})();
