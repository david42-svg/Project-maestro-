// chord-vocab.js — the token vocabulary for the Phase 3 prediction model.
// This is the CONTRACT between the browser (onnx-lab.js) and the Python
// training pipeline (see /training). Both sides must build this list the
// same way, in the same order, or token indices won't line up.
//
// 12 roots x 9 qualities + 1 padding/unknown token = 109 tokens.

const ChordVocab = (function(){
  'use strict';

  const ROOTS = ['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'];
  const QUALITIES = ['maj', 'min', '7', 'maj7', 'min7', 'm7b5', 'dim', 'sus2', 'sus4'];

  const tokens = ['<pad>'];
  ROOTS.forEach(function(root){
    QUALITIES.forEach(function(quality){
      tokens.push(root + quality);
    });
  });
  // tokens.length === 1 + 12*9 === 109

  const tokenToIndex = {};
  tokens.forEach(function(t, i){ tokenToIndex[t] = i; });

  function size(){ return tokens.length; }
  function indexOf(token){ return Object.prototype.hasOwnProperty.call(tokenToIndex, token) ? tokenToIndex[token] : 0; }
  function tokenAt(index){ return tokens[index] || '<pad>'; }

  return { ROOTS: ROOTS, QUALITIES: QUALITIES, tokens: tokens, size: size, indexOf: indexOf, tokenAt: tokenAt };
})();
