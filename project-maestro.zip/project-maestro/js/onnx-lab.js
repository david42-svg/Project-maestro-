// onnx-lab.js — Phase 3 task 3.2: run an ONNX model client-side.
//
// IMPORTANT: models/diagnostic.onnx is NOT a chord model. It's a genuine,
// tiny ONNX file (elementwise square, [3,2] -> [3,2]) borrowed from
// onnxruntime's own test suite, used here purely to prove that session
// creation, execution-provider selection (WebGPU with WASM fallback),
// tensor construction, and reading results back all actually work in this
// browser — which is the real risk in "run it in-browser", not the model
// content. Once training.py / colab_train.ipynb produces a real
// chord-model.onnx matching the contract in chord-vocab.js, swap the path
// in runDiagnostic()'s caller (or add a second loader) and the rest of this
// harness — session handling, EP fallback, error surfacing — doesn't change.

const OnnxLab = (function(){
  'use strict';

  const MODEL_URL = 'models/diagnostic.onnx';
  const EXPECTED_INPUT = [[1, 2], [3, 4], [5, 6]];
  const EXPECTED_OUTPUT = [[1, 4], [9, 16], [25, 36]]; // elementwise square

  let session = null;
  let sessionEP = null;

  async function loadSession(onLog){
    if (typeof ort === 'undefined'){
      throw new Error('onnxruntime-web failed to load — check your internet connection.');
    }
    const attempts = [
      { label: 'webgpu', providers: ['webgpu'] },
      { label: 'wasm', providers: ['wasm'] }
    ];
    for (let i = 0; i < attempts.length; i++){
      const attempt = attempts[i];
      try{
        onLog('Trying execution provider: ' + attempt.label + '…');
        const t0 = performance.now();
        session = await ort.InferenceSession.create(MODEL_URL, {
          executionProviders: attempt.providers,
          graphOptimizationLevel: 'all'
        });
        const loadMs = performance.now() - t0;
        sessionEP = attempt.label;
        onLog('Session created with "' + attempt.label + '" in ' + loadMs.toFixed(0) + 'ms.');
        return { ep: attempt.label, loadMs: loadMs };
      } catch (err){
        onLog('"' + attempt.label + '" failed: ' + (err && err.message ? err.message : err));
      }
    }
    throw new Error('No execution provider worked (tried webgpu, wasm).');
  }

  function flatten(arr2d){
    const out = [];
    arr2d.forEach(function(row){ row.forEach(function(v){ out.push(v); }); });
    return out;
  }

  function unflatten(flat, rows, cols){
    const out = [];
    for (let r = 0; r < rows; r++){
      out.push(Array.from(flat.slice(r * cols, r * cols + cols)));
    }
    return out;
  }

  function approxEqual(a, b, eps){
    if (a.length !== b.length) return false;
    for (let i = 0; i < a.length; i++){
      if (a[i].length !== b[i].length) return false;
      for (let j = 0; j < a[i].length; j++){
        if (Math.abs(a[i][j] - b[i][j]) > eps) return false;
      }
    }
    return true;
  }

  // Runs the diagnostic model and checks the output against the known-correct
  // answer, so a "pass" here means real, verified, numerically-correct
  // inference happened in this browser — not just "a file loaded".
  async function runDiagnostic(onLog){
    onLog = onLog || function(){};
    if (!session){
      await loadSession(onLog);
    }

    const inputData = Float32Array.from(flatten(EXPECTED_INPUT));
    const tensor = new ort.Tensor('float32', inputData, [3, 2]);

    const t0 = performance.now();
    const results = await session.run({ X: tensor });
    const runMs = performance.now() - t0;

    const outputTensor = results.Y;
    const outputArr = unflatten(Array.from(outputTensor.data), 3, 2);
    const correct = approxEqual(outputArr, EXPECTED_OUTPUT, 1e-4);

    return {
      ep: sessionEP,
      runMs: runMs,
      input: EXPECTED_INPUT,
      output: outputArr,
      expected: EXPECTED_OUTPUT,
      correct: correct
    };
  }

  function reset(){
    session = null;
    sessionEP = null;
  }

  return { runDiagnostic: runDiagnostic, reset: reset, MODEL_URL: MODEL_URL };
})();
