// phase3.js — UI wiring for "The Decision Engine" (rules-based v1)
// Requires audio-engine.js and flow-engine.js, both loaded before this file.

(function(){
  'use strict';

  const startGate = document.getElementById('startGate');
  const startBtn = document.getElementById('startBtn');
  const stopBtn = document.getElementById('stopBtn');
  const liveArea = document.getElementById('liveArea');
  const errorBox = document.getElementById('errorBox');
  const statusIndicator = document.getElementById('statusIndicator');
  const statusText = document.getElementById('statusText');

  const flowStateLabel = document.getElementById('flowStateLabel');
  const flowDot = document.getElementById('flowDot');
  const flowSince = document.getElementById('flowSince');
  const flowReasons = document.getElementById('flowReasons');
  const flowSuggestion = document.getElementById('flowSuggestion');

  const bpmValueEl = document.getElementById('bpmValue');
  const keyValueEl = document.getElementById('keyValue');
  const dbValueEl = document.getElementById('dbValue');

  let rafId = null;
  let lastFlowPushTime = 0;
  const FLOW_PUSH_INTERVAL_SEC = 0.5; // throttle FlowEngine updates — see flow-engine.js hysteresis notes

  function showError(message){ errorBox.textContent = message; errorBox.classList.add('is-visible'); }
  function clearError(){ errorBox.textContent = ''; errorBox.classList.remove('is-visible'); }
  function setStatus(live, label){ statusText.textContent = label; statusIndicator.classList.toggle('is-live', !!live); }

  function renderFlow(result){
    const state = result.state;
    flowStateLabel.textContent = FlowEngine.STATE_LABELS[state] || state;
    flowStateLabel.className = 'flow-state-label flow-' + state;
    flowSince.textContent = 'for ' + Math.round(result.sinceSeconds) + 's';
    flowReasons.textContent = result.reasons.join(' · ');
    flowSuggestion.textContent = FlowEngine.STATE_SUGGESTIONS[state] || '';
  }

  function updateUI(){
    const s = AudioEngine.snapshot();
    const audioContext = AudioEngine.getAudioContext();
    const now = audioContext ? audioContext.currentTime : 0;

    bpmValueEl.textContent = s.bpm ? Math.round(s.bpm) : '--';
    keyValueEl.textContent = s.keyName || '--';
    dbValueEl.textContent = s.smoothedDb <= -59.5 ? '-∞' : s.smoothedDb.toFixed(1);

    if (now - lastFlowPushTime >= FLOW_PUSH_INTERVAL_SEC){
      lastFlowPushTime = now;
      const result = FlowEngine.push(s, now);
      renderFlow(result);
    }

    rafId = requestAnimationFrame(updateUI);
  }

  async function start(){
    clearError();
    startBtn.disabled = true;
    setStatus(false, 'Requesting mic…');

    const result = await AudioEngine.start();

    if (!result.ok){
      startBtn.disabled = false;
      setStatus(false, 'Idle');
      if (result.reason === 'insecure-context'){
        showError('This page needs to be served over HTTPS (or opened at localhost) for microphone access to work.');
      } else if (result.reason === 'unsupported'){
        showError('This browser does not support microphone capture. Try a recent version of Chrome, Edge, or Firefox.');
      } else if (result.reason === 'mic-error'){
        const err = result.error;
        if (err && err.name === 'NotAllowedError'){
          showError('Microphone access was blocked. Allow microphone access for this page in your browser settings, then press Start again.');
        } else if (err && err.name === 'NotFoundError'){
          showError('No microphone was found on this device.');
        } else {
          showError('Could not start the microphone (' + (err && err.message ? err.message : 'unknown error') + ').');
        }
      }
      return;
    }

    startGate.style.display = 'none';
    liveArea.style.display = '';
    stopBtn.style.display = '';
    setStatus(true, 'Listening');

    lastFlowPushTime = 0;
    FlowEngine.reset(0);
    rafId = requestAnimationFrame(updateUI);
  }

  function stop(){
    if (rafId) cancelAnimationFrame(rafId);
    rafId = null;
    AudioEngine.stop();

    liveArea.style.display = 'none';
    startGate.style.display = '';
    stopBtn.style.display = 'none';
    startBtn.disabled = false;
    setStatus(false, 'Idle');
  }

  startBtn.addEventListener('click', start);
  stopBtn.addEventListener('click', stop);

  // ---------------------------------------------------------------
  // ONNX diagnostic panel
  // ---------------------------------------------------------------
  const onnxRunBtn = document.getElementById('onnxRunBtn');
  const onnxLog = document.getElementById('onnxLog');
  const onnxResult = document.getElementById('onnxResult');
  const onnxBadge = document.getElementById('onnxBadge');
  const onnxTiming = document.getElementById('onnxTiming');
  const contractVocabSize = document.getElementById('contractVocabSize');

  if (contractVocabSize && typeof ChordVocab !== 'undefined'){
    contractVocabSize.textContent = ChordVocab.size();
  }

  function onnxLogLine(text){
    onnxLog.style.display = '';
    onnxLog.textContent += (onnxLog.textContent ? '\n' : '') + text;
    onnxLog.scrollTop = onnxLog.scrollHeight;
  }

  if (onnxRunBtn){
    onnxRunBtn.addEventListener('click', async function(){
      onnxRunBtn.disabled = true;
      onnxLog.textContent = '';
      onnxLog.style.display = '';
      onnxResult.style.display = 'none';

      try{
        const result = await OnnxLab.runDiagnostic(onnxLogLine);
        onnxLogLine('Ran session.run() in ' + result.runMs.toFixed(1) + 'ms.');
        onnxLogLine('input:  ' + JSON.stringify(result.input));
        onnxLogLine('output: ' + JSON.stringify(result.output));
        onnxLogLine('expected: ' + JSON.stringify(result.expected));

        onnxBadge.textContent = result.correct ? 'Pipeline verified ✓' : 'Output mismatch ✗';
        onnxBadge.className = 'onnx-badge ' + (result.correct ? 'pass' : 'fail');
        onnxTiming.textContent = 'execution provider: ' + result.ep + ' · inference: ' + result.runMs.toFixed(1) + 'ms';
        onnxResult.style.display = '';
      } catch (err){
        onnxLogLine('ERROR: ' + (err && err.message ? err.message : err));
        onnxBadge.textContent = 'Failed';
        onnxBadge.className = 'onnx-badge fail';
        onnxTiming.textContent = '';
        onnxResult.style.display = '';
      } finally {
        onnxRunBtn.disabled = false;
      }
    });
  }

  // ---------------------------------------------------------------
  // Real chord prediction (trained model)
  // ---------------------------------------------------------------
  const predictHistoryInput = document.getElementById('predictHistoryInput');
  const predictSectionSelect = document.getElementById('predictSectionSelect');
  const predictBtn = document.getElementById('predictBtn');
  const predictErrorBox = document.getElementById('predictErrorBox');
  const predictResults = document.getElementById('predictResults');
  const predictMeta = document.getElementById('predictMeta');

  function showPredictError(msg){ predictErrorBox.textContent = msg; predictErrorBox.classList.add('is-visible'); }
  function clearPredictError(){ predictErrorBox.textContent = ''; predictErrorBox.classList.remove('is-visible'); }

  function renderPredictions(result){
    predictResults.innerHTML = '';
    result.ranked.forEach(function(r, i){
      const row = document.createElement('div');
      row.className = 'predict-row';

      const rank = document.createElement('span');
      rank.className = 'predict-rank';
      rank.textContent = '#' + (i + 1);

      const token = document.createElement('span');
      token.className = 'predict-token';
      token.textContent = r.token;

      const barTrack = document.createElement('div');
      barTrack.className = 'predict-bar-track';
      const barFill = document.createElement('div');
      barFill.className = 'predict-bar-fill';
      barFill.style.width = Math.round(r.prob * 100) + '%';
      barTrack.appendChild(barFill);

      const pct = document.createElement('span');
      pct.className = 'predict-pct';
      pct.textContent = (r.prob * 100).toFixed(1) + '%';

      row.appendChild(rank);
      row.appendChild(token);
      row.appendChild(barTrack);
      row.appendChild(pct);
      predictResults.appendChild(row);
    });
    predictResults.style.display = '';
    predictMeta.textContent = 'execution provider: ' + result.ep + ' · inference: ' + result.runMs.toFixed(1) +
      'ms · history used (after padding/truncation): ' + result.historyUsed.join(' ');
  }

  if (predictBtn){
    predictBtn.addEventListener('click', async function(){
      clearPredictError();
      predictBtn.disabled = true;
      predictResults.style.display = 'none';
      predictMeta.textContent = '';

      const raw = predictHistoryInput.value.trim();
      if (!raw){
        showPredictError('Type at least one chord token, e.g. Cmaj Amin Fmaj Gmaj.');
        predictBtn.disabled = false;
        return;
      }
      const tokens = raw.split(/[\s,]+/).filter(Boolean);
      const unknown = tokens.filter(function(t){ return ChordVocab.indexOf(t) === 0 && t !== '<pad>'; });
      if (unknown.length){
        showPredictError('Not in the model\u2019s vocabulary, skipped as padding: ' + unknown.join(', ') +
          '. Use tokens exactly like js/chord-vocab.js (e.g. Cmaj, Amin, C7, F#maj7) — not Tonal-style symbols like Cmaj7add9.');
      }

      try{
        const result = await ChordPredictor.predict(tokens, predictSectionSelect.value, 5, function(){});
        renderPredictions(result);
      } catch (err){
        showPredictError('Prediction failed: ' + (err && err.message ? err.message : err));
      } finally {
        predictBtn.disabled = false;
      }
    });
  }
})();
