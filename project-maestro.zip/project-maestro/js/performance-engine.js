// performance-engine.js — the Tone.js audio chain + chord scheduler.
// Extracted out of phase4.js so a second page (live.js) can play chords
// through the exact same audio pipeline, filters, and limiter — a future
// audio fix (like the clipping fix) only has to happen in one place.
// Requires Tone.js (CDN) and engine.js (for STYLES) loaded before this file.
// Callers own their own DOM; this module never touches an element directly.

const PerformanceEngine = (function(){
  'use strict';

  const HUMANIZE = {
    none:   { timeJitter: 0,     velJitter: 0,    baseVel: 0.85 },
    subtle: { timeJitter: 0.008, velJitter: 0.06, baseVel: 0.80 },
    loose:  { timeJitter: 0.020, velJitter: 0.15, baseVel: 0.75 }
  };

  // Syncopation "pushes" a chord's entire onset earlier than its nominal
  // beat — a deliberate anticipation, not the small symmetric-either-way
  // jitter HUMANIZE already does. amount is a fraction of ONE BEAT (not
  // the whole chord), applied only some of the time (chance) so it reads
  // as a rhythmic choice rather than the whole progression rushing.
  const SYNCOPATION = {
    none: { chance: 0,    amount: 0 },
    some: { chance: 0.30, amount: 0.25 },
    lots: { chance: 0.50, amount: 0.40 }
  };

  const SCHEDULE_AHEAD_SEC = 0.3;
  const LOOKAHEAD_MS = 100;

  // ================================================================
  // Audio chain — see js/phase4.js history for why the limiter/filters
  // exist: nothing did before, and dense chords could hard-clip.
  // Signal chain: bassSynth -> bassFilter -\
  //                                          +-> compressor -> limiter -> destination
  //               padSynth -> padHighpass -> padLowpass -> padGain -/
  // ================================================================
  let bassSynth = null, padSynth = null, toneReady = false;
  let bassFilter = null, padHighpass = null, padLowpass = null, padGain = null;

  function ensureSynths(){
    if (toneReady) return;

    const compressor = new Tone.Compressor({ threshold: -18, ratio: 3, attack: 0.01, release: 0.15 });
    const limiter = new Tone.Limiter(-1); // hard ceiling at -1dBFS — nothing gets past this, ever
    compressor.connect(limiter);
    limiter.toDestination();

    bassFilter = new Tone.Filter({ type: 'lowpass', frequency: 900, Q: 0.5 });
    bassFilter.connect(compressor);
    // PolySynth, not a plain Synth — Solo mode gives the left hand a real
    // 2-note chord (root+fifth), and a monophonic synth can only sound one
    // of those notes at a time.
    bassSynth = new Tone.PolySynth(Tone.Synth);
    bassSynth.set({ oscillator: { type: 'sine' }, envelope: { attack: 0.02, decay: 0.2, sustain: 0.6, release: 0.3 } });
    bassSynth.connect(bassFilter);

    padHighpass = new Tone.Filter({ type: 'highpass', frequency: 90, Q: 0.4 });
    padLowpass = new Tone.Filter({ type: 'lowpass', frequency: 6000, Q: 0.5 });
    padGain = new Tone.Gain(1);
    padHighpass.connect(padLowpass);
    padLowpass.connect(padGain);
    padGain.connect(compressor);

    padSynth = new Tone.PolySynth(Tone.Synth);
    padSynth.set({ oscillator: { type: 'triangle' }, envelope: { attack: 0.08, decay: 0.3, sustain: 0.8, release: 0.6 } });
    padSynth.connect(padHighpass);

    toneReady = true;
  }

  // Retunes the shared filters/gain for the style currently selected.
  function applyStyleToAudioChain(style){
    if (!toneReady) return;
    const cfg = STYLES[style];
    if (!cfg) return;
    padHighpass.frequency.value = cfg.padHighpassHz;
    padLowpass.frequency.value = cfg.padLowpassHz;
    padGain.gain.value = Tone.dbToGain(cfg.padGainDb);
  }

  function jitter(amount){ return amount ? (Math.random() * 2 - 1) * amount : 0; }
  function clampVel(v){ return Math.max(0.05, Math.min(1, v)); }

  // ================================================================
  // Web MIDI (optional — Chrome/Edge/Firefox only, not Safari/iOS).
  // This module never builds a <select> itself — it hands back plain
  // {id, name} data and lets the caller render it however it wants.
  // ================================================================
  let midiAccessObj = null;
  let midiOutput = null;

  function audioTimeToPerfTime(audioTime){
    return performance.now() + (audioTime - Tone.now()) * 1000;
  }

  function scheduleMidiNote(midiNote, time, duration, velocity){
    if (!midiOutput) return;
    const velByte = Math.max(1, Math.min(127, Math.round(velocity * 127)));
    try {
      midiOutput.send([0x90, midiNote, velByte], audioTimeToPerfTime(time));
      midiOutput.send([0x80, midiNote, 0], audioTimeToPerfTime(time + duration));
    } catch (e){ /* ignore malformed timestamps on some browsers */ }
  }

  function listMidiOutputs(){
    const arr = [];
    if (midiAccessObj){
      midiAccessObj.outputs.forEach(function(output, id){ arr.push({ id: id, name: output.name }); });
    }
    return arr;
  }

  async function connectMidi(onOutputsChanged){
    if (!navigator.requestMIDIAccess){
      return { ok: false, reason: 'unsupported' };
    }
    try{
      midiAccessObj = await navigator.requestMIDIAccess();
      midiAccessObj.onstatechange = function(){
        if (onOutputsChanged) onOutputsChanged(listMidiOutputs());
      };
      return { ok: true, outputs: listMidiOutputs() };
    } catch (e){
      return { ok: false, reason: 'blocked' };
    }
  }

  function selectMidiOutput(id){
    midiOutput = (id && midiAccessObj) ? midiAccessObj.outputs.get(id) : null;
  }

  // ================================================================
  // Playback state + scheduler
  // ================================================================
  let arrangement = [];
  let currentStyle = 'worship';
  let opts = { bpm: 92, beatsPerChord: 4, humanize: 'subtle', syncopation: 'none', ghostNotes: false, loop: true };
  let isPlaying = false;
  let chordIndex = 0;
  let nextChordTime = 0;
  let schedulerTimer = null;
  let onChordChange = null; // callback(index, chord)
  let onStop = null;        // callback() — fires whether stopped manually or the arrangement ended

  function secondsPerChord(){
    const bpm = Math.max(20, Number(opts.bpm) || 92);
    const beats = Math.max(1, Number(opts.beatsPerChord) || 4);
    return (60 / bpm) * beats;
  }

  function computeSyncopationShiftSec(){
    const syncCfg = SYNCOPATION[opts.syncopation] || SYNCOPATION.none;
    if (syncCfg.chance > 0 && Math.random() < syncCfg.chance){
      const bpm = Math.max(20, Number(opts.bpm) || 92);
      const beatSec = 60 / bpm;
      return beatSec * syncCfg.amount;
    }
    return 0;
  }

  function scheduleChordAt(index, time){
    const chord = arrangement[index];
    if (!chord || chord.error) return;
    const cfg = STYLES[currentStyle];
    const h = HUMANIZE[opts.humanize] || HUMANIZE.subtle;
    const chordDur = secondsPerChord();

    const syncShift = computeSyncopationShiftSec();
    const hitTime = Math.max(time - syncShift, Tone.now() + 0.005);

    if (opts.ghostNotes){
      const ghostLeadSec = 0.05 + Math.random() * 0.03; // 50-80ms early
      const ghostTime = hitTime - ghostLeadSec;
      if (ghostTime > Tone.now() + 0.002){
        const ghostVel = 0.10 + Math.random() * 0.04;
        chord.lhMidis.forEach(function(midi){
          bassSynth.triggerAttackRelease(noteNameFromMidi(midi), 0.08, ghostTime, ghostVel);
        });
        chord.rhMidis.forEach(function(midi){
          padSynth.triggerAttackRelease(noteNameFromMidi(midi), 0.08, ghostTime, ghostVel);
        });
      }
    }

    chord.lhMidis.forEach(function(midi){
      const noteTime = hitTime + jitter(h.timeJitter);
      const vel = clampVel(h.baseVel + jitter(h.velJitter));
      const dur = chordDur * cfg.bassSustain;
      bassSynth.triggerAttackRelease(noteNameFromMidi(midi), dur, noteTime, vel);
      scheduleMidiNote(midi, noteTime, dur, vel);
    });

    chord.rhMidis.forEach(function(midi){
      const noteTime = hitTime + jitter(h.timeJitter);
      const vel = clampVel(h.baseVel + jitter(h.velJitter));
      const dur = chordDur * cfg.rhSustain;
      padSynth.triggerAttackRelease(noteNameFromMidi(midi), dur, noteTime, vel);
      scheduleMidiNote(midi, noteTime, dur, vel);
    });

    const msUntil = Math.max(0, (hitTime - Tone.now()) * 1000);
    setTimeout(function(){
      if (onChordChange) onChordChange(index, chord);
    }, msUntil);
  }

  function schedulerTick(){
    while (nextChordTime < Tone.now() + SCHEDULE_AHEAD_SEC){
      scheduleChordAt(chordIndex, nextChordTime);
      const dur = secondsPerChord();
      nextChordTime += dur;
      chordIndex += 1;
      if (chordIndex >= arrangement.length){
        if (opts.loop){
          chordIndex = 0;
        } else {
          const stopDelayMs = Math.max(0, (nextChordTime - Tone.now()) * 1000);
          setTimeout(stop, stopDelayMs);
          clearInterval(schedulerTimer);
          schedulerTimer = null;
          return;
        }
      }
    }
  }

  function stop(){
    isPlaying = false;
    if (schedulerTimer){ clearInterval(schedulerTimer); schedulerTimer = null; }
    if (onStop) onStop();
  }

  // arr: output of buildArrangement(). style: STYLES key (for sustain/filters).
  // options: { bpm, beatsPerChord, humanize, syncopation, ghostNotes, loop }
  // callbacks: { onChordChange(index, chord), onStop() }
  async function play(arr, style, options, callbacks){
    if (!arr || !arr.length) return { ok: false, reason: 'empty-arrangement' };

    arrangement = arr;
    currentStyle = style;
    opts = Object.assign({ bpm: 92, beatsPerChord: 4, humanize: 'subtle', syncopation: 'none', ghostNotes: false, loop: true }, options || {});
    onChordChange = (callbacks && callbacks.onChordChange) || null;
    onStop = (callbacks && callbacks.onStop) || null;

    ensureSynths();
    applyStyleToAudioChain(currentStyle);
    await Tone.start();

    isPlaying = true;
    chordIndex = 0;
    nextChordTime = Tone.now() + 0.15;

    schedulerTick();
    schedulerTimer = setInterval(schedulerTick, LOOKAHEAD_MS);
    return { ok: true };
  }

  function isActive(){ return isPlaying; }

  // ================================================================
  // Live single-chord triggering — for a continuously-decided chord
  // stream (harmonizer now, future chord-recognition later), as opposed
  // to a pre-built arrangement played on a fixed beat grid. There's no
  // known "chord duration" here — the next chord arrives whenever the
  // harmonizer decides it does — so this holds each chord with sustained
  // attack/release rather than the scheduled play()'s fixed-duration hits.
  // ================================================================
  let liveHeldLhMidis = [];
  let liveHeldRhMidis = [];

  async function startLive(style){
    ensureSynths();
    applyStyleToAudioChain(style);
    await Tone.start();
    liveHeldLhMidis = [];
    liveHeldRhMidis = [];
  }

  // lhMidis/rhMidis: the voicing to hold now (e.g. from LiveVoicer).
  function triggerLiveChord(lhMidis, rhMidis){
    if (!toneReady) return;
    const h = HUMANIZE.subtle;
    const now = Tone.now() + 0.02;

    if (liveHeldLhMidis.length) bassSynth.triggerRelease(liveHeldLhMidis.map(noteNameFromMidi), now);
    if (liveHeldRhMidis.length) padSynth.triggerRelease(liveHeldRhMidis.map(noteNameFromMidi), now);

    const vel = clampVel(h.baseVel);
    lhMidis.forEach(function(midi){
      bassSynth.triggerAttack(noteNameFromMidi(midi), now + jitter(h.timeJitter), vel);
    });
    rhMidis.forEach(function(midi){
      padSynth.triggerAttack(noteNameFromMidi(midi), now + jitter(h.timeJitter), vel);
    });

    liveHeldLhMidis = lhMidis;
    liveHeldRhMidis = rhMidis;
  }

  function stopLive(){
    if (!toneReady) return;
    const now = Tone.now();
    if (liveHeldLhMidis.length) bassSynth.triggerRelease(liveHeldLhMidis.map(noteNameFromMidi), now);
    if (liveHeldRhMidis.length) padSynth.triggerRelease(liveHeldRhMidis.map(noteNameFromMidi), now);
    liveHeldLhMidis = [];
    liveHeldRhMidis = [];
  }

  return {
    ensureSynths: ensureSynths,
    applyStyleToAudioChain: applyStyleToAudioChain,
    connectMidi: connectMidi,
    selectMidiOutput: selectMidiOutput,
    play: play,
    stop: stop,
    isActive: isActive,
    startLive: startLive,
    triggerLiveChord: triggerLiveChord,
    stopLive: stopLive
  };
})();
