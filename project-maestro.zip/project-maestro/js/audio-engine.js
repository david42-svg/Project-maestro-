// audio-engine.js — shared by phase1.js and phase3.js
// Owns: microphone capture, the audio graph, and all DSP (tempo/key/dynamics).
// Exposes a small API; callers own their own DOM/rendering.

const AudioEngine = (function(){
  'use strict';

  // ---------------------------------------------------------------
  // Constants
  // ---------------------------------------------------------------
  const PITCH_NAMES = ['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'];
  const KS_MAJOR = [6.35,2.23,3.48,2.33,4.38,4.09,2.52,5.19,2.39,3.66,2.29,2.88];
  const KS_MINOR = [6.33,2.68,3.52,5.38,2.60,3.53,2.54,4.75,3.98,2.69,3.34,3.17];

  const CHROMA_MIN_FREQ = 80;
  const CHROMA_MAX_FREQ = 4000;
  const CHROMA_DECAY = 0.965;

  const ONSET_HISTORY_SEC = 1.5;
  const ONSET_MIN_INTERVAL = 0.2;
  const ONSET_SENSITIVITY = 1.35;
  const IOI_WINDOW_SEC = 8;

  // ---------------------------------------------------------------
  // Audio graph state
  // ---------------------------------------------------------------
  let audioContext = null;
  let mediaStream = null;
  let analyserNode = null;
  let meterNode = null;
  let scriptFallbackNode = null;
  let running = false;

  // ---------------------------------------------------------------
  // Tempo tracker — energy-based onset detection + histogram voting
  // ---------------------------------------------------------------
  function createTempoTracker(){
    return {
      energyHistory: [],
      onsetTimes: [],
      lastOnsetTime: -Infinity,
      histogram: new Map(),
      currentBpm: null,
      confidence: 0,
      lastBeatTime: null,
      beatInterval: null
    };
  }

  let tempo = createTempoTracker();

  function pushEnergy(tracker, rms, time){
    tracker.energyHistory.push({ time: time, rms: rms });
    const cutoff = time - ONSET_HISTORY_SEC;
    while (tracker.energyHistory.length && tracker.energyHistory[0].time < cutoff){
      tracker.energyHistory.shift();
    }
    if (tracker.energyHistory.length < 4) return;

    let sum = 0;
    for (let i = 0; i < tracker.energyHistory.length; i++) sum += tracker.energyHistory[i].rms;
    const avg = sum / tracker.energyHistory.length;
    const threshold = Math.max(avg * ONSET_SENSITIVITY, 0.015);

    if (rms > threshold && (time - tracker.lastOnsetTime) > ONSET_MIN_INTERVAL){
      registerOnset(tracker, time);
      tracker.lastOnsetTime = time;
    }
  }

  function registerOnset(tracker, time){
    tracker.onsetTimes.push(time);
    const cutoff = time - IOI_WINDOW_SEC;
    while (tracker.onsetTimes.length && tracker.onsetTimes[0] < cutoff){
      tracker.onsetTimes.shift();
    }
    if (tracker.onsetTimes.length < 2) return;

    const ioi = time - tracker.onsetTimes[tracker.onsetTimes.length - 2];
    if (ioi <= 0) return;

    let bpm = 60 / ioi;
    while (bpm < 70) bpm *= 2;
    while (bpm > 180) bpm /= 2;
    const bucket = Math.round(bpm);

    tracker.histogram.forEach(function(v, k){ tracker.histogram.set(k, v * 0.95); });
    tracker.histogram.set(bucket, (tracker.histogram.get(bucket) || 0) + 1);

    let total = 0;
    tracker.histogram.forEach(function(v){ total += v; });

    let bestBucket = null, bestScore = 0;
    tracker.histogram.forEach(function(_v, k){
      let score = 0;
      for (let d = -2; d <= 2; d++) score += tracker.histogram.get(k + d) || 0;
      if (score > bestScore){ bestScore = score; bestBucket = k; }
    });

    if (bestBucket !== null){
      tracker.currentBpm = tracker.currentBpm ? (tracker.currentBpm * 0.7 + bestBucket * 0.3) : bestBucket;
      tracker.confidence = total > 0 ? Math.min(1, bestScore / total) : 0;
      tracker.beatInterval = 60 / tracker.currentBpm;
      tracker.lastBeatTime = time;
    }
  }

  // ---------------------------------------------------------------
  // Key tracker — chroma accumulation + Krumhansl-Schmuckler match
  // ---------------------------------------------------------------
  const chromaRunning = new Array(12).fill(0);

  function rotateProfile(profile, rootOffset){
    const out = new Array(12);
    for (let i = 0; i < 12; i++){
      out[i] = profile[(i - rootOffset + 12) % 12];
    }
    return out;
  }

  function correlate(x, y){
    const n = x.length;
    let meanX = 0, meanY = 0;
    for (let i = 0; i < n; i++){ meanX += x[i]; meanY += y[i]; }
    meanX /= n; meanY /= n;
    let num = 0, dx2 = 0, dy2 = 0;
    for (let i = 0; i < n; i++){
      const dx = x[i] - meanX, dy = y[i] - meanY;
      num += dx * dy; dx2 += dx * dx; dy2 += dy * dy;
    }
    const denom = Math.sqrt(dx2 * dy2);
    return denom === 0 ? 0 : num / denom;
  }

  function estimateKey(chroma){
    let best = { score: -Infinity, root: 0, mode: 'Major' };
    for (let root = 0; root < 12; root++){
      const majScore = correlate(chroma, rotateProfile(KS_MAJOR, root));
      const minScore = correlate(chroma, rotateProfile(KS_MINOR, root));
      if (majScore > best.score) best = { score: majScore, root: root, mode: 'Major' };
      if (minScore > best.score) best = { score: minScore, root: root, mode: 'Minor' };
    }
    return best;
  }

  function updateChromaFromAnalyser(){
    if (!analyserNode) return;
    const freqData = new Float32Array(analyserNode.frequencyBinCount);
    analyserNode.getFloatFrequencyData(freqData);

    const sampleRate = audioContext.sampleRate;
    const fftSize = analyserNode.fftSize;
    const minBin = Math.max(1, Math.floor(CHROMA_MIN_FREQ * fftSize / sampleRate));
    const maxBin = Math.min(freqData.length - 1, Math.ceil(CHROMA_MAX_FREQ * fftSize / sampleRate));

    const frame = new Array(12).fill(0);
    for (let i = minBin; i <= maxBin; i++){
      const db = freqData[i];
      if (!isFinite(db) || db < -100) continue;
      const freq = i * sampleRate / fftSize;
      const midi = 69 + 12 * Math.log2(freq / 440);
      const pitchClass = ((Math.round(midi) % 12) + 12) % 12;
      const linear = Math.pow(10, db / 20);
      frame[pitchClass] += linear;
    }

    let sum = 0;
    for (let i = 0; i < 12; i++) sum += frame[i];
    if (sum > 0){
      for (let i = 0; i < 12; i++) frame[i] /= sum;
    }

    for (let i = 0; i < 12; i++){
      chromaRunning[i] = chromaRunning[i] * CHROMA_DECAY + frame[i] * (1 - CHROMA_DECAY);
    }
  }

  // ---------------------------------------------------------------
  // Dynamics (VU) state
  // ---------------------------------------------------------------
  let smoothedDb = -60;
  let peakDb = -60;
  let lastPeakDecayTime = 0;

  function dbFromRms(rms){
    return 20 * Math.log10(Math.max(rms, 1e-8));
  }

  function updateDynamics(rms, time){
    const db = dbFromRms(rms);
    smoothedDb = smoothedDb * 0.7 + db * 0.3;
    if (db > peakDb){
      peakDb = db;
    } else {
      const dt = time - lastPeakDecayTime;
      peakDb -= dt * 12;
    }
    lastPeakDecayTime = time;
    peakDb = Math.max(peakDb, -60);
  }

  // ---------------------------------------------------------------
  // Worklet processor source (loaded via Blob URL — no separate file)
  // ---------------------------------------------------------------
  const WORKLET_SOURCE = [
    'class MeterProcessor extends AudioWorkletProcessor {',
    '  constructor(){',
    '    super();',
    '    this.frameSize = 1024;',
    '    this.buffer = new Float32Array(this.frameSize);',
    '    this.index = 0;',
    '  }',
    '  process(inputs){',
    '    const input = inputs[0];',
    '    if (input && input.length > 0){',
    '      const channel = input[0];',
    '      for (let i = 0; i < channel.length; i++){',
    '        this.buffer[this.index++] = channel[i];',
    '        if (this.index >= this.frameSize){',
    '          let sumSquares = 0;',
    '          for (let j = 0; j < this.frameSize; j++){',
    '            const s = this.buffer[j];',
    '            sumSquares += s * s;',
    '          }',
    '          const rms = Math.sqrt(sumSquares / this.frameSize);',
    '          this.port.postMessage({ rms: rms, time: currentTime });',
    '          this.index = 0;',
    '        }',
    '      }',
    '    }',
    '    return true;',
    '  }',
    '}',
    'registerProcessor("meter-processor", MeterProcessor);'
  ].join('\n');

  function handleMeterFrame(rms, time){
    updateDynamics(rms, time);
    pushEnergy(tempo, rms, time);
  }

  function setupScriptFallback(source, silentSink){
    scriptFallbackNode = audioContext.createScriptProcessor(1024, 1, 1);
    scriptFallbackNode.onaudioprocess = function(e){
      const channel = e.inputBuffer.getChannelData(0);
      let sumSquares = 0;
      for (let i = 0; i < channel.length; i++) sumSquares += channel[i] * channel[i];
      const rms = Math.sqrt(sumSquares / channel.length);
      handleMeterFrame(rms, audioContext.currentTime);
    };
    source.connect(scriptFallbackNode);
    scriptFallbackNode.connect(silentSink);
  }

  // ---------------------------------------------------------------
  // Public: start / stop
  // ---------------------------------------------------------------
  async function start(){
    if (!window.isSecureContext){
      return { ok: false, reason: 'insecure-context' };
    }
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia){
      return { ok: false, reason: 'unsupported' };
    }

    try{
      mediaStream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false }
      });
    } catch (err){
      return { ok: false, reason: 'mic-error', error: err };
    }

    audioContext = new (window.AudioContext || window.webkitAudioContext)();
    if (audioContext.state === 'suspended'){
      try { await audioContext.resume(); } catch (e){ /* ignore */ }
    }

    const source = audioContext.createMediaStreamSource(mediaStream);

    analyserNode = audioContext.createAnalyser();
    analyserNode.fftSize = 4096;
    analyserNode.smoothingTimeConstant = 0.25;

    const silentSink = audioContext.createGain();
    silentSink.gain.value = 0;
    silentSink.connect(audioContext.destination);

    source.connect(analyserNode);
    analyserNode.connect(silentSink);

    try{
      const blob = new Blob([WORKLET_SOURCE], { type: 'application/javascript' });
      const workletUrl = URL.createObjectURL(blob);
      await audioContext.audioWorklet.addModule(workletUrl);
      meterNode = new AudioWorkletNode(audioContext, 'meter-processor');
      meterNode.port.onmessage = function(e){ handleMeterFrame(e.data.rms, e.data.time); };
      source.connect(meterNode);
      meterNode.connect(silentSink);
    } catch (workletErr){
      setupScriptFallback(source, silentSink);
    }

    tempo = createTempoTracker();
    for (let i = 0; i < 12; i++) chromaRunning[i] = 0;
    smoothedDb = -60;
    peakDb = -60;
    lastPeakDecayTime = audioContext.currentTime;
    running = true;

    return { ok: true, sampleRate: audioContext.sampleRate };
  }

  function stop(){
    if (mediaStream){
      mediaStream.getTracks().forEach(function(track){ track.stop(); });
      mediaStream = null;
    }
    if (meterNode){ meterNode.disconnect(); meterNode = null; }
    if (scriptFallbackNode){ scriptFallbackNode.disconnect(); scriptFallbackNode = null; }
    if (analyserNode){ analyserNode.disconnect(); analyserNode = null; }
    if (audioContext){
      audioContext.close().catch(function(){});
      audioContext = null;
    }
    running = false;
  }

  function isRunning(){ return running; }
  function getAnalyserNode(){ return analyserNode; }
  function getAudioContext(){ return audioContext; }

  // ---------------------------------------------------------------
  // Pitch tracking (YIN, via pitch-detector.js) — throttled, since a full
  // YIN pass is real work (O(tauMax * bufferLength)) and doesn't need to
  // run every animation frame. A sung note doesn't change meaningfully
  // faster than a few times a second, so this is plenty responsive.
  // ---------------------------------------------------------------
  const PITCH_UPDATE_INTERVAL_SEC = 0.1;
  let lastPitchUpdateTime = -Infinity;
  let lastPitchResult = null;

  function updatePitchIfDue(){
    if (!analyserNode || !audioContext) return;
    const now = audioContext.currentTime;
    if (now - lastPitchUpdateTime < PITCH_UPDATE_INTERVAL_SEC) return;
    lastPitchUpdateTime = now;
    if (typeof PitchDetector === 'undefined') return; // graceful no-op if the script wasn't loaded on this page
    lastPitchResult = PitchDetector.detectFromAnalyser(analyserNode, audioContext.sampleRate);
  }

  // Call once per animation frame while running — returns the latest
  // computed tempo/key/dynamics state for the caller to render or act on.
  function snapshot(){
    updateChromaFromAnalyser();
    updatePitchIfDue();
    const keyResult = estimateKey(chromaRunning);
    const chromaSum = chromaRunning.reduce(function(a, b){ return a + b; }, 0);
    const hasKey = chromaSum > 0.001;

    return {
      bpm: tempo.currentBpm,
      bpmConfidence: tempo.confidence,
      beatInterval: tempo.beatInterval,
      lastBeatTime: tempo.lastBeatTime,
      keyRoot: hasKey ? keyResult.root : null,
      keyMode: hasKey ? keyResult.mode : null,
      keyName: hasKey ? (PITCH_NAMES[keyResult.root] + ' ' + keyResult.mode) : null,
      keyConfidence: hasKey ? Math.max(0, Math.min(1, keyResult.score)) : 0,
      chroma: chromaRunning.slice(),
      chromaSum: chromaSum,
      smoothedDb: smoothedDb,
      peakDb: peakDb,
      pitch: lastPitchResult
    };
  }

  return {
    start: start,
    stop: stop,
    isRunning: isRunning,
    getAnalyserNode: getAnalyserNode,
    getAudioContext: getAudioContext,
    snapshot: snapshot,
    PITCH_NAMES: PITCH_NAMES
  };
})();
