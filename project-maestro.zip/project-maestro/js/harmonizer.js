// harmonizer.js — Solo-mode melody harmonization ("Track A": rule-based
// diatonic harmony, not a trained model — see phase discussion history).
//
// Given a sung pitch class + the key Phase 1 already detects, picks a
// diatonic chord that contains that note, preferring options that (a) use
// the note as a stronger chord tone (3rd > root > 5th), (b) move the least
// from the previous chord's root, and (c) follow a few common functional
// resolutions. This is deliberately simple — triads only, natural-minor
// diatonic set only, no borrowed chords or secondary dominants. Documented
// simplification, not hidden: real congregational worship harmony is mostly
// diatonic, so this covers the common case; it will not reharmonize like a
// jazz pianist.
//
// Requires chord-vocab.js (for PITCH_NAMES-equivalent root spelling) loaded
// before this file — reuses AudioEngine.PITCH_NAMES equivalent spelling via
// its own local copy to avoid a hard dependency on audio-engine.js.

const Harmonizer = (function(){
  'use strict';

  const PITCH_NAMES = ['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'];

  // Diatonic triads by scale degree, as semitone offsets from the tonic.
  const DIATONIC_MAJOR = [
    { degree: 'I',   pcOffset: 0,  quality: 'maj' },
    { degree: 'ii',  pcOffset: 2,  quality: 'min' },
    { degree: 'iii', pcOffset: 4,  quality: 'min' },
    { degree: 'IV',  pcOffset: 5,  quality: 'maj' },
    { degree: 'V',   pcOffset: 7,  quality: 'maj' },
    { degree: 'vi',  pcOffset: 9,  quality: 'min' },
    { degree: 'vii', pcOffset: 11, quality: 'dim' }
  ];
  // Natural minor. (Not harmonic/melodic minor — another documented
  // simplification; a raised-7th V chord in minor is a common real
  // exception this won't produce.)
  const DIATONIC_MINOR = [
    { degree: 'i',   pcOffset: 0,  quality: 'min' },
    { degree: 'ii',  pcOffset: 2,  quality: 'dim' },
    { degree: 'III', pcOffset: 3,  quality: 'maj' },
    { degree: 'iv',  pcOffset: 5,  quality: 'min' },
    { degree: 'v',   pcOffset: 7,  quality: 'min' },
    { degree: 'VI',  pcOffset: 8,  quality: 'maj' },
    { degree: 'VII', pcOffset: 10, quality: 'maj' }
  ];

  // Modest, hand-picked functional-harmony preferences — a small nudge
  // toward common resolutions, not a full cadence model.
  const PREFERRED_NEXT = {
    'V': ['I', 'i'], 'vii': ['I', 'i'], 'IV': ['V', 'I'], 'ii': ['V'],
    'iv': ['V', 'v'], 'VII': ['III'], 'v': ['i'], 'VI': ['V', 'v']
  };

  function triadPitchClasses(rootPc, quality){
    const thirdOffset = (quality === 'maj') ? 4 : 3;
    const fifthOffset = (quality === 'dim') ? 6 : 7;
    return [rootPc, (rootPc + thirdOffset) % 12, (rootPc + fifthOffset) % 12];
  }

  function buildDiatonicChords(keyRootPc, keyMode){
    const table = (keyMode === 'Minor') ? DIATONIC_MINOR : DIATONIC_MAJOR;
    return table.map(function(entry){
      const rootPc = (keyRootPc + entry.pcOffset) % 12;
      return {
        degree: entry.degree,
        rootPc: rootPc,
        quality: entry.quality,
        tones: triadPitchClasses(rootPc, entry.quality),
        token: PITCH_NAMES[rootPc] + entry.quality
      };
    });
  }

  function circularDistance(a, b){
    const diff = Math.abs(a - b) % 12;
    return Math.min(diff, 12 - diff);
  }

  const PRIMARY_DEGREES = { 'I': true, 'IV': true, 'V': true, 'i': true, 'iv': true, 'v': true };

  function scoreCandidate(candidate, sungPc, prevRootPc, prevDegree){
    const toneIndex = candidate.tones.indexOf(sungPc);
    if (toneIndex === -1) return -Infinity; // doesn't contain the sung note — disqualified

    // Primary triads (I/IV/V) are overwhelmingly the most common harmonization
    // in simple diatonic music — this needs to dominate, or a case as basic as
    // "singing the tonic note" can lose to a secondary chord (that was a real
    // bug here: scoring the melody note's role in the chord too heavily made
    // singing scale-degree-1 resolve to vi instead of I, since C sits as vi's
    // third — technically true, but the wrong answer for the common case).
    let score = PRIMARY_DEGREES[candidate.degree] ? 3 : 0;

    // Tone role is now a light tiebreaker only, not the deciding factor.
    score += (toneIndex === 0) ? 0.6 : (toneIndex === 1 ? 0.4 : 0.2); // root > third > fifth

    if (prevRootPc !== null){
      const dist = circularDistance(candidate.rootPc, prevRootPc);
      score += (6 - dist) * 0.3;
    }
    if (prevDegree && PREFERRED_NEXT[prevDegree] && PREFERRED_NEXT[prevDegree].indexOf(candidate.degree) !== -1){
      score += 1.5;
    }
    return score;
  }

  // ---------------------------------------------------------------
  // Stateful session — mirrors flow-engine.js's hysteresis pattern so a
  // single passing/chromatic note doesn't yank the chord around.
  // ---------------------------------------------------------------
  const MIN_HOLD_SEC = 0.7;
  const VOTE_STREAK_NEEDED = 2;

  let currentChord = null;
  let currentChordSince = 0;
  let pendingCandidate = null;
  let pendingStreak = 0;

  function reset(){
    currentChord = null;
    currentChordSince = 0;
    pendingCandidate = null;
    pendingStreak = 0;
  }

  // sungPc: 0-11. keyRootPc: 0-11. keyMode: 'Major'|'Minor'. timeSec: elapsed
  // wall-clock seconds (e.g. audioContext.currentTime) — NOT a beat count.
  // A solo sustained voice may never produce reliable onset/beat detection
  // (Phase 1's tempo tracker is tuned for percussive attacks), so hysteresis
  // here is gated on real time instead, the same proven pattern
  // flow-engine.js already uses for flow-state hysteresis.
  // Returns the current chord ({degree, token, rootPc, quality, tones}) or
  // null if nothing has been established yet.
  function harmonize(sungPc, keyRootPc, keyMode, timeSec){
    if (sungPc === null || sungPc === undefined || keyRootPc === null || keyRootPc === undefined){
      return currentChord;
    }

    const diatonic = buildDiatonicChords(keyRootPc, keyMode);
    const prevRootPc = currentChord ? currentChord.rootPc : null;
    const prevDegree = currentChord ? currentChord.degree : null;

    let best = null, bestScore = -Infinity;
    diatonic.forEach(function(c){
      const s = scoreCandidate(c, sungPc, prevRootPc, prevDegree);
      if (s > bestScore){ bestScore = s; best = c; }
    });

    if (!best){
      // Sung note isn't in any diatonic triad of the detected key (a
      // passing tone, a chromatic note, or the key estimate is off) — hold
      // the current chord rather than guessing wildly off one bad frame.
      return currentChord;
    }

    if (!currentChord){
      currentChord = best;
      currentChordSince = timeSec;
      pendingCandidate = null;
      pendingStreak = 0;
      return currentChord;
    }

    if (best.token !== currentChord.token){
      if (pendingCandidate && pendingCandidate.token === best.token){
        pendingStreak += 1;
      } else {
        pendingCandidate = best;
        pendingStreak = 1;
      }
      const heldLongEnough = (timeSec - currentChordSince) >= MIN_HOLD_SEC;
      if (pendingStreak >= VOTE_STREAK_NEEDED && heldLongEnough){
        currentChord = best;
        currentChordSince = timeSec;
        pendingCandidate = null;
        pendingStreak = 0;
      }
    } else {
      pendingCandidate = null;
      pendingStreak = 0;
    }

    return currentChord;
  }

  return { harmonize: harmonize, reset: reset, buildDiatonicChords: buildDiatonicChords };
})();
