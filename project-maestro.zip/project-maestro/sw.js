const CACHE_NAME = 'ai-keyboardist-maestro-v6';

const APP_SHELL = [
  './',
  './index.html',
  './phase1.html',
  './phase2.html',
  './phase3.html',
  './phase4.html',
  './live.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png',
  './icon-180.png',
  './css/shared.css',
  './js/engine.js',
  './js/audio-engine.js',
  './js/flow-engine.js',
  './js/chord-vocab.js',
  './js/onnx-lab.js',
  './js/pitch-detector.js',
  './js/harmonizer.js',
  './js/chord-predictor.js',
  './js/performance-engine.js',
  './js/phase1.js',
  './js/phase2.js',
  './js/phase3.js',
  './js/phase4.js',
  './js/live.js',
  './models/diagnostic.onnx',
  './models/chord-model.onnx',
  './models/vocab.json',
  'https://cdn.jsdelivr.net/npm/tonal/browser/tonal.min.js',
  'https://unpkg.com/tone@14/build/Tone.js',
  'https://cdn.jsdelivr.net/npm/onnxruntime-web@1.21.0/dist/ort.min.js'
];
// Note: onnxruntime-web also fetches its own .wasm binaries at runtime from
// the same CDN path. Those aren't listed individually here (the exact
// filenames are an onnxruntime-web internal detail) — the generic fetch
// handler below caches them opportunistically the first time they load
// successfully, so offline use works after one successful run with a
// connection.

self.addEventListener('install', function(event){
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(function(cache){ return cache.addAll(APP_SHELL); })
      .then(function(){ return self.skipWaiting(); })
      .catch(function(){ /* if a CDN is unreachable at install time, keep going —
                            the fetch handler below will still cache it on first
                            successful load */ })
  );
});

self.addEventListener('activate', function(event){
  event.waitUntil(
    caches.keys()
      .then(function(keys){
        return Promise.all(keys.filter(function(k){ return k !== CACHE_NAME; }).map(function(k){ return caches.delete(k); }));
      })
      .then(function(){ return self.clients.claim(); })
  );
});

self.addEventListener('fetch', function(event){
  if (event.request.method !== 'GET') return;

  event.respondWith(
    caches.match(event.request).then(function(cached){
      if (cached) return cached;
      return fetch(event.request).then(function(response){
        const copy = response.clone();
        caches.open(CACHE_NAME).then(function(cache){ cache.put(event.request, copy); });
        return response;
      }).catch(function(){ return cached; });
    })
  );
});
